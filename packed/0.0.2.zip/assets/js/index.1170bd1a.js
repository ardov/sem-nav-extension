import{r,$ as Ot,b as rt,d as It,j as $,a as G,F as ze,R as re,c as Rt}from"./jsx-runtime.d4d474d3.js";function O(){return O=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e},O.apply(this,arguments)}function Y(e,t,{checkForDefaultPrevented:n=!0}={}){return function(a){if(e==null||e(a),n===!1||!a.defaultPrevented)return t==null?void 0:t(a)}}function Mt(e,t){typeof e=="function"?e(t):e!=null&&(e.current=t)}function at(...e){return t=>e.forEach(n=>Mt(n,t))}function Q(...e){return r.exports.useCallback(at(...e),e)}function zt(e,t=[]){let n=[];function o(s,c){const i=r.exports.createContext(c),l=n.length;n=[...n,c];function u(m){const{scope:y,children:b,...C}=m,p=(y==null?void 0:y[e][l])||i,w=r.exports.useMemo(()=>C,Object.values(C));return r.exports.createElement(p.Provider,{value:w},b)}function h(m,y){const b=(y==null?void 0:y[e][l])||i,C=r.exports.useContext(b);if(C)return C;if(c!==void 0)return c;throw new Error(`\`${m}\` must be used within \`${s}\``)}return u.displayName=s+"Provider",[u,h]}const a=()=>{const s=n.map(c=>r.exports.createContext(c));return function(i){const l=(i==null?void 0:i[e])||s;return r.exports.useMemo(()=>({[`__scope${e}`]:{...i,[e]:l}}),[i,l])}};return a.scopeName=e,[o,Ft(a,...t)]}function Ft(...e){const t=e[0];if(e.length===1)return t;const n=()=>{const o=e.map(a=>({useScope:a(),scopeName:a.scopeName}));return function(s){const c=o.reduce((i,{useScope:l,scopeName:u})=>{const m=l(s)[`__scope${u}`];return{...i,...m}},{});return r.exports.useMemo(()=>({[`__scope${t.scopeName}`]:c}),[c])}};return n.scopeName=t.scopeName,n}const Pe=Boolean(globalThis==null?void 0:globalThis.document)?r.exports.useLayoutEffect:()=>{},Gt=Ot["useId".toString()]||(()=>{});let Dt=0;function ye(e){const[t,n]=r.exports.useState(Gt());return Pe(()=>{e||n(o=>o!=null?o:String(Dt++))},[e]),e||(t?`radix-${t}`:"")}function B(e){const t=r.exports.useRef(e);return r.exports.useEffect(()=>{t.current=e}),r.exports.useMemo(()=>(...n)=>{var o;return(o=t.current)===null||o===void 0?void 0:o.call(t,...n)},[])}function Lt({prop:e,defaultProp:t,onChange:n=()=>{}}){const[o,a]=Bt({defaultProp:t,onChange:n}),s=e!==void 0,c=s?e:o,i=B(n),l=r.exports.useCallback(u=>{if(s){const m=typeof u=="function"?u(e):u;m!==e&&i(m)}else a(u)},[s,e,a,i]);return[c,l]}function Bt({defaultProp:e,onChange:t}){const n=r.exports.useState(e),[o]=n,a=r.exports.useRef(o),s=B(t);return r.exports.useEffect(()=>{a.current!==o&&(s(o),a.current=o)},[o,a,s]),n}const Fe=r.exports.forwardRef((e,t)=>{const{children:n,...o}=e,a=r.exports.Children.toArray(n),s=a.find(Ut);if(s){const c=s.props.children,i=a.map(l=>l===s?r.exports.Children.count(c)>1?r.exports.Children.only(null):r.exports.isValidElement(c)?c.props.children:null:l);return r.exports.createElement(Te,O({},o,{ref:t}),r.exports.isValidElement(c)?r.exports.cloneElement(c,void 0,i):null)}return r.exports.createElement(Te,O({},o,{ref:t}),n)});Fe.displayName="Slot";const Te=r.exports.forwardRef((e,t)=>{const{children:n,...o}=e;return r.exports.isValidElement(n)?r.exports.cloneElement(n,{...Nt(o,n.props),ref:at(t,n.ref)}):r.exports.Children.count(n)>1?r.exports.Children.only(null):null});Te.displayName="SlotClone";const _t=({children:e})=>r.exports.createElement(r.exports.Fragment,null,e);function Ut(e){return r.exports.isValidElement(e)&&e.type===_t}function Nt(e,t){const n={...t};for(const o in t){const a=e[o],s=t[o];/^on[A-Z]/.test(o)?n[o]=(...i)=>{s==null||s(...i),a==null||a(...i)}:o==="style"?n[o]={...a,...s}:o==="className"&&(n[o]=[a,s].filter(Boolean).join(" "))}return{...e,...n}}const Wt=["a","button","div","h2","h3","img","li","nav","ol","p","span","svg","ul"],pe=Wt.reduce((e,t)=>{const n=r.exports.forwardRef((o,a)=>{const{asChild:s,...c}=o,i=s?Fe:t;return r.exports.useEffect(()=>{window[Symbol.for("radix-ui")]=!0},[]),r.exports.createElement(i,O({},c,{ref:a}))});return n.displayName=`Primitive.${t}`,{...e,[t]:n}},{});function Kt(e,t){e&&rt.exports.flushSync(()=>e.dispatchEvent(t))}function Yt(e){const t=B(e);r.exports.useEffect(()=>{const n=o=>{o.key==="Escape"&&t(o)};return document.addEventListener("keydown",n),()=>document.removeEventListener("keydown",n)},[t])}const $e="dismissableLayer.update",Ht="dismissableLayer.pointerDownOutside",qt="dismissableLayer.focusOutside";let Ke;const jt=r.exports.createContext({layers:new Set,layersWithOutsidePointerEventsDisabled:new Set,branches:new Set}),Vt=r.exports.forwardRef((e,t)=>{const{disableOutsidePointerEvents:n=!1,onEscapeKeyDown:o,onPointerDownOutside:a,onFocusOutside:s,onInteractOutside:c,onDismiss:i,...l}=e,u=r.exports.useContext(jt),[h,m]=r.exports.useState(null),[,y]=r.exports.useState({}),b=Q(t,E=>m(E)),C=Array.from(u.layers),[p]=[...u.layersWithOutsidePointerEventsDisabled].slice(-1),w=C.indexOf(p),g=h?C.indexOf(h):-1,x=u.layersWithOutsidePointerEventsDisabled.size>0,A=g>=w,k=Zt(E=>{const I=E.target,M=[...u.branches].some(z=>z.contains(I));!A||M||(a==null||a(E),c==null||c(E),E.defaultPrevented||i==null||i())}),P=Xt(E=>{const I=E.target;[...u.branches].some(z=>z.contains(I))||(s==null||s(E),c==null||c(E),E.defaultPrevented||i==null||i())});return Yt(E=>{g===u.layers.size-1&&(o==null||o(E),!E.defaultPrevented&&i&&(E.preventDefault(),i()))}),r.exports.useEffect(()=>{if(!!h)return n&&(u.layersWithOutsidePointerEventsDisabled.size===0&&(Ke=document.body.style.pointerEvents,document.body.style.pointerEvents="none"),u.layersWithOutsidePointerEventsDisabled.add(h)),u.layers.add(h),Ye(),()=>{n&&u.layersWithOutsidePointerEventsDisabled.size===1&&(document.body.style.pointerEvents=Ke)}},[h,n,u]),r.exports.useEffect(()=>()=>{!h||(u.layers.delete(h),u.layersWithOutsidePointerEventsDisabled.delete(h),Ye())},[h,u]),r.exports.useEffect(()=>{const E=()=>y({});return document.addEventListener($e,E),()=>document.removeEventListener($e,E)},[]),r.exports.createElement(pe.div,O({},l,{ref:b,style:{pointerEvents:x?A?"auto":"none":void 0,...e.style},onFocusCapture:Y(e.onFocusCapture,P.onFocusCapture),onBlurCapture:Y(e.onBlurCapture,P.onBlurCapture),onPointerDownCapture:Y(e.onPointerDownCapture,k.onPointerDownCapture)}))});function Zt(e){const t=B(e),n=r.exports.useRef(!1),o=r.exports.useRef(()=>{});return r.exports.useEffect(()=>{const a=c=>{if(c.target&&!n.current){let l=function(){st(Ht,t,i,{discrete:!0})};const i={originalEvent:c};c.pointerType==="touch"?(document.removeEventListener("click",o.current),o.current=l,document.addEventListener("click",o.current,{once:!0})):l()}n.current=!1},s=window.setTimeout(()=>{document.addEventListener("pointerdown",a)},0);return()=>{window.clearTimeout(s),document.removeEventListener("pointerdown",a),document.removeEventListener("click",o.current)}},[t]),{onPointerDownCapture:()=>n.current=!0}}function Xt(e){const t=B(e),n=r.exports.useRef(!1);return r.exports.useEffect(()=>{const o=a=>{a.target&&!n.current&&st(qt,t,{originalEvent:a},{discrete:!1})};return document.addEventListener("focusin",o),()=>document.removeEventListener("focusin",o)},[t]),{onFocusCapture:()=>n.current=!0,onBlurCapture:()=>n.current=!1}}function Ye(){const e=new CustomEvent($e);document.dispatchEvent(e)}function st(e,t,n,{discrete:o}){const a=n.originalEvent.target,s=new CustomEvent(e,{bubbles:!1,cancelable:!0,detail:n});t&&a.addEventListener(e,t,{once:!0}),o?Kt(a,s):a.dispatchEvent(s)}const ve="focusScope.autoFocusOnMount",we="focusScope.autoFocusOnUnmount",He={bubbles:!1,cancelable:!0},Jt=r.exports.forwardRef((e,t)=>{const{loop:n=!1,trapped:o=!1,onMountAutoFocus:a,onUnmountAutoFocus:s,...c}=e,[i,l]=r.exports.useState(null),u=B(a),h=B(s),m=r.exports.useRef(null),y=Q(t,p=>l(p)),b=r.exports.useRef({paused:!1,pause(){this.paused=!0},resume(){this.paused=!1}}).current;r.exports.useEffect(()=>{if(o){let p=function(g){if(b.paused||!i)return;const x=g.target;i.contains(x)?m.current=x:L(m.current,{select:!0})},w=function(g){b.paused||!i||i.contains(g.relatedTarget)||L(m.current,{select:!0})};return document.addEventListener("focusin",p),document.addEventListener("focusout",w),()=>{document.removeEventListener("focusin",p),document.removeEventListener("focusout",w)}}},[o,i,b.paused]),r.exports.useEffect(()=>{if(i){je.add(b);const p=document.activeElement;if(!i.contains(p)){const g=new CustomEvent(ve,He);i.addEventListener(ve,u),i.dispatchEvent(g),g.defaultPrevented||(Qt(rn(it(i)),{select:!0}),document.activeElement===p&&L(i))}return()=>{i.removeEventListener(ve,u),setTimeout(()=>{const g=new CustomEvent(we,He);i.addEventListener(we,h),i.dispatchEvent(g),g.defaultPrevented||L(p!=null?p:document.body,{select:!0}),i.removeEventListener(we,h),je.remove(b)},0)}}},[i,u,h,b]);const C=r.exports.useCallback(p=>{if(!n&&!o||b.paused)return;const w=p.key==="Tab"&&!p.altKey&&!p.ctrlKey&&!p.metaKey,g=document.activeElement;if(w&&g){const x=p.currentTarget,[A,k]=en(x);A&&k?!p.shiftKey&&g===k?(p.preventDefault(),n&&L(A,{select:!0})):p.shiftKey&&g===A&&(p.preventDefault(),n&&L(k,{select:!0})):g===x&&p.preventDefault()}},[n,o,b.paused]);return r.exports.createElement(pe.div,O({tabIndex:-1},c,{ref:y,onKeyDown:C}))});function Qt(e,{select:t=!1}={}){const n=document.activeElement;for(const o of e)if(L(o,{select:t}),document.activeElement!==n)return}function en(e){const t=it(e),n=qe(t,e),o=qe(t.reverse(),e);return[n,o]}function it(e){const t=[],n=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:o=>{const a=o.tagName==="INPUT"&&o.type==="hidden";return o.disabled||o.hidden||a?NodeFilter.FILTER_SKIP:o.tabIndex>=0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}});for(;n.nextNode();)t.push(n.currentNode);return t}function qe(e,t){for(const n of e)if(!tn(n,{upTo:t}))return n}function tn(e,{upTo:t}){if(getComputedStyle(e).visibility==="hidden")return!0;for(;e;){if(t!==void 0&&e===t)return!1;if(getComputedStyle(e).display==="none")return!0;e=e.parentElement}return!1}function nn(e){return e instanceof HTMLInputElement&&"select"in e}function L(e,{select:t=!1}={}){if(e&&e.focus){const n=document.activeElement;e.focus({preventScroll:!0}),e!==n&&nn(e)&&t&&e.select()}}const je=on();function on(){let e=[];return{add(t){const n=e[0];t!==n&&(n==null||n.pause()),e=Ve(e,t),e.unshift(t)},remove(t){var n;e=Ve(e,t),(n=e[0])===null||n===void 0||n.resume()}}}function Ve(e,t){const n=[...e],o=n.indexOf(t);return o!==-1&&n.splice(o,1),n}function rn(e){return e.filter(t=>t.tagName!=="A")}const an=r.exports.forwardRef((e,t)=>{var n;const{container:o=globalThis==null||(n=globalThis.document)===null||n===void 0?void 0:n.body,...a}=e;return o?It.createPortal(r.exports.createElement(pe.div,O({},a,{ref:t})),o):null});function sn(e,t){return r.exports.useReducer((n,o)=>{const a=t[n][o];return a!=null?a:n},e)}const me=e=>{const{present:t,children:n}=e,o=cn(t),a=typeof n=="function"?n({present:o.isPresent}):r.exports.Children.only(n),s=Q(o.ref,a.ref);return typeof n=="function"||o.isPresent?r.exports.cloneElement(a,{ref:s}):null};me.displayName="Presence";function cn(e){const[t,n]=r.exports.useState(),o=r.exports.useRef({}),a=r.exports.useRef(e),s=r.exports.useRef("none"),c=e?"mounted":"unmounted",[i,l]=sn(c,{mounted:{UNMOUNT:"unmounted",ANIMATION_OUT:"unmountSuspended"},unmountSuspended:{MOUNT:"mounted",ANIMATION_END:"unmounted"},unmounted:{MOUNT:"mounted"}});return r.exports.useEffect(()=>{const u=ae(o.current);s.current=i==="mounted"?u:"none"},[i]),Pe(()=>{const u=o.current,h=a.current;if(h!==e){const y=s.current,b=ae(u);e?l("MOUNT"):b==="none"||(u==null?void 0:u.display)==="none"?l("UNMOUNT"):l(h&&y!==b?"ANIMATION_OUT":"UNMOUNT"),a.current=e}},[e,l]),Pe(()=>{if(t){const u=m=>{const b=ae(o.current).includes(m.animationName);m.target===t&&b&&rt.exports.flushSync(()=>l("ANIMATION_END"))},h=m=>{m.target===t&&(s.current=ae(o.current))};return t.addEventListener("animationstart",h),t.addEventListener("animationcancel",u),t.addEventListener("animationend",u),()=>{t.removeEventListener("animationstart",h),t.removeEventListener("animationcancel",u),t.removeEventListener("animationend",u)}}else l("ANIMATION_END")},[t,l]),{isPresent:["mounted","unmountSuspended"].includes(i),ref:r.exports.useCallback(u=>{u&&(o.current=getComputedStyle(u)),n(u)},[])}}function ae(e){return(e==null?void 0:e.animationName)||"none"}let be=0;function un(){r.exports.useEffect(()=>{var e,t;const n=document.querySelectorAll("[data-radix-focus-guard]");return document.body.insertAdjacentElement("afterbegin",(e=n[0])!==null&&e!==void 0?e:Ze()),document.body.insertAdjacentElement("beforeend",(t=n[1])!==null&&t!==void 0?t:Ze()),be++,()=>{be===1&&document.querySelectorAll("[data-radix-focus-guard]").forEach(o=>o.remove()),be--}},[])}function Ze(){const e=document.createElement("span");return e.setAttribute("data-radix-focus-guard",""),e.tabIndex=0,e.style.cssText="outline: none; opacity: 0; position: fixed; pointer-events: none",e}var F=function(){return F=Object.assign||function(t){for(var n,o=1,a=arguments.length;o<a;o++){n=arguments[o];for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&(t[s]=n[s])}return t},F.apply(this,arguments)};function ct(e,t){var n={};for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&t.indexOf(o)<0&&(n[o]=e[o]);if(e!=null&&typeof Object.getOwnPropertySymbols=="function")for(var a=0,o=Object.getOwnPropertySymbols(e);a<o.length;a++)t.indexOf(o[a])<0&&Object.prototype.propertyIsEnumerable.call(e,o[a])&&(n[o[a]]=e[o[a]]);return n}function ln(e,t,n){if(n||arguments.length===2)for(var o=0,a=t.length,s;o<a;o++)(s||!(o in t))&&(s||(s=Array.prototype.slice.call(t,0,o)),s[o]=t[o]);return e.concat(s||Array.prototype.slice.call(t))}var le="right-scroll-bar-position",de="width-before-scroll-bar",dn="with-scroll-bars-hidden",pn="--removed-body-scroll-bar-size";function mn(e,t){return typeof e=="function"?e(t):e&&(e.current=t),e}function hn(e,t){var n=r.exports.useState(function(){return{value:e,callback:t,facade:{get current(){return n.value},set current(o){var a=n.value;a!==o&&(n.value=o,n.callback(o,a))}}}})[0];return n.callback=t,n.facade}function fn(e,t){return hn(t||null,function(n){return e.forEach(function(o){return mn(o,n)})})}function gn(e){return e}function yn(e,t){t===void 0&&(t=gn);var n=[],o=!1,a={read:function(){if(o)throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");return n.length?n[n.length-1]:e},useMedium:function(s){var c=t(s,o);return n.push(c),function(){n=n.filter(function(i){return i!==c})}},assignSyncMedium:function(s){for(o=!0;n.length;){var c=n;n=[],c.forEach(s)}n={push:function(i){return s(i)},filter:function(){return n}}},assignMedium:function(s){o=!0;var c=[];if(n.length){var i=n;n=[],i.forEach(s),c=n}var l=function(){var h=c;c=[],h.forEach(s)},u=function(){return Promise.resolve().then(l)};u(),n={push:function(h){c.push(h),u()},filter:function(h){return c=c.filter(h),n}}}};return a}function vn(e){e===void 0&&(e={});var t=yn(null);return t.options=F({async:!0,ssr:!1},e),t}var ut=function(e){var t=e.sideCar,n=ct(e,["sideCar"]);if(!t)throw new Error("Sidecar: please provide `sideCar` property to import the right car");var o=t.read();if(!o)throw new Error("Sidecar medium not found");return $(o,{...F({},n)})};ut.isSideCarExport=!0;function wn(e,t){return e.useMedium(t),ut}var lt=vn(),ke=function(){},he=r.exports.forwardRef(function(e,t){var n=r.exports.useRef(null),o=r.exports.useState({onScrollCapture:ke,onWheelCapture:ke,onTouchMoveCapture:ke}),a=o[0],s=o[1],c=e.forwardProps,i=e.children,l=e.className,u=e.removeScrollBar,h=e.enabled,m=e.shards,y=e.sideCar,b=e.noIsolation,C=e.inert,p=e.allowPinchZoom,w=e.as,g=w===void 0?"div":w,x=ct(e,["forwardProps","children","className","removeScrollBar","enabled","shards","sideCar","noIsolation","inert","allowPinchZoom","as"]),A=y,k=fn([n,t]),P=F(F({},x),a);return G(ze,{children:[h&&$(A,{sideCar:lt,removeScrollBar:u,shards:m,noIsolation:b,inert:C,setCallbacks:s,allowPinchZoom:!!p,lockRef:n}),c?r.exports.cloneElement(r.exports.Children.only(i),F(F({},P),{ref:k})):$(g,{...F({},P,{className:l,ref:k}),children:i})]})});he.defaultProps={enabled:!0,removeScrollBar:!0,inert:!1};he.classNames={fullWidth:de,zeroRight:le};var bn=function(){if(typeof __webpack_nonce__<"u")return __webpack_nonce__};function kn(){if(!document)return null;var e=document.createElement("style");e.type="text/css";var t=bn();return t&&e.setAttribute("nonce",t),e}function Sn(e,t){e.styleSheet?e.styleSheet.cssText=t:e.appendChild(document.createTextNode(t))}function An(e){var t=document.head||document.getElementsByTagName("head")[0];t.appendChild(e)}var En=function(){var e=0,t=null;return{add:function(n){e==0&&(t=kn())&&(Sn(t,n),An(t)),e++},remove:function(){e--,!e&&t&&(t.parentNode&&t.parentNode.removeChild(t),t=null)}}},Cn=function(){var e=En();return function(t,n){r.exports.useEffect(function(){return e.add(t),function(){e.remove()}},[t&&n])}},dt=function(){var e=Cn(),t=function(n){var o=n.styles,a=n.dynamic;return e(o,a),null};return t},xn={left:0,top:0,right:0,gap:0},Se=function(e){return parseInt(e||"",10)||0},Pn=function(e){var t=window.getComputedStyle(document.body),n=t[e==="padding"?"paddingLeft":"marginLeft"],o=t[e==="padding"?"paddingTop":"marginTop"],a=t[e==="padding"?"paddingRight":"marginRight"];return[Se(n),Se(o),Se(a)]},Tn=function(e){if(e===void 0&&(e="margin"),typeof window>"u")return xn;var t=Pn(e),n=document.documentElement.clientWidth,o=window.innerWidth;return{left:t[0],top:t[1],right:t[2],gap:Math.max(0,o-n+t[2]-t[0])}},$n=dt(),On=function(e,t,n,o){var a=e.left,s=e.top,c=e.right,i=e.gap;return n===void 0&&(n="margin"),`
  .`.concat(dn,` {
   overflow: hidden `).concat(o,`;
   padding-right: `).concat(i,"px ").concat(o,`;
  }
  body {
    overflow: hidden `).concat(o,`;
    overscroll-behavior: contain;
    `).concat([t&&"position: relative ".concat(o,";"),n==="margin"&&`
    padding-left: `.concat(a,`px;
    padding-top: `).concat(s,`px;
    padding-right: `).concat(c,`px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(i,"px ").concat(o,`;
    `),n==="padding"&&"padding-right: ".concat(i,"px ").concat(o,";")].filter(Boolean).join(""),`
  }
  
  .`).concat(le,` {
    right: `).concat(i,"px ").concat(o,`;
  }
  
  .`).concat(de,` {
    margin-right: `).concat(i,"px ").concat(o,`;
  }
  
  .`).concat(le," .").concat(le,` {
    right: 0 `).concat(o,`;
  }
  
  .`).concat(de," .").concat(de,` {
    margin-right: 0 `).concat(o,`;
  }
  
  body {
    `).concat(pn,": ").concat(i,`px;
  }
`)},In=function(e){var t=e.noRelative,n=e.noImportant,o=e.gapMode,a=o===void 0?"margin":o,s=r.exports.useMemo(function(){return Tn(a)},[a]);return $($n,{styles:On(s,!t,a,n?"":"!important")})},Oe=!1;if(typeof window<"u")try{var se=Object.defineProperty({},"passive",{get:function(){return Oe=!0,!0}});window.addEventListener("test",se,se),window.removeEventListener("test",se,se)}catch{Oe=!1}var U=Oe?{passive:!1}:!1,Rn=function(e){var t=window.getComputedStyle(e);return t.overflowY!=="hidden"&&!(t.overflowY===t.overflowX&&t.overflowY==="visible")},Mn=function(e){var t=window.getComputedStyle(e);return t.overflowX!=="hidden"&&!(t.overflowY===t.overflowX&&t.overflowX==="visible")},Xe=function(e,t){var n=t;do{typeof ShadowRoot<"u"&&n instanceof ShadowRoot&&(n=n.host);var o=pt(e,n);if(o){var a=mt(e,n),s=a[1],c=a[2];if(s>c)return!0}n=n.parentNode}while(n&&n!==document.body);return!1},zn=function(e){var t=e.scrollTop,n=e.scrollHeight,o=e.clientHeight;return[t,n,o]},Fn=function(e){var t=e.scrollLeft,n=e.scrollWidth,o=e.clientWidth;return[t,n,o]},pt=function(e,t){return e==="v"?Rn(t):Mn(t)},mt=function(e,t){return e==="v"?zn(t):Fn(t)},Gn=function(e,t){return e==="h"&&t==="rtl"?-1:1},Dn=function(e,t,n,o,a){var s=Gn(e,window.getComputedStyle(t).direction),c=s*o,i=n.target,l=t.contains(i),u=!1,h=c>0,m=0,y=0;do{var b=mt(e,i),C=b[0],p=b[1],w=b[2],g=p-w-s*C;(C||g)&&pt(e,i)&&(m+=g,y+=C),i=i.parentNode}while(!l&&i!==document.body||l&&(t.contains(i)||t===i));return(h&&(a&&m===0||!a&&c>m)||!h&&(a&&y===0||!a&&-c>y))&&(u=!0),u},ie=function(e){return"changedTouches"in e?[e.changedTouches[0].clientX,e.changedTouches[0].clientY]:[0,0]},Je=function(e){return[e.deltaX,e.deltaY]},Qe=function(e){return e&&"current"in e?e.current:e},Ln=function(e,t){return e[0]===t[0]&&e[1]===t[1]},Bn=function(e){return`
  .block-interactivity-`.concat(e,` {pointer-events: none;}
  .allow-interactivity-`).concat(e,` {pointer-events: all;}
`)},_n=0,N=[];function Un(e){var t=r.exports.useRef([]),n=r.exports.useRef([0,0]),o=r.exports.useRef(),a=r.exports.useState(_n++)[0],s=r.exports.useState(function(){return dt()})[0],c=r.exports.useRef(e);r.exports.useEffect(function(){c.current=e},[e]),r.exports.useEffect(function(){if(e.inert){document.body.classList.add("block-interactivity-".concat(a));var p=ln([e.lockRef.current],(e.shards||[]).map(Qe),!0).filter(Boolean);return p.forEach(function(w){return w.classList.add("allow-interactivity-".concat(a))}),function(){document.body.classList.remove("block-interactivity-".concat(a)),p.forEach(function(w){return w.classList.remove("allow-interactivity-".concat(a))})}}},[e.inert,e.lockRef.current,e.shards]);var i=r.exports.useCallback(function(p,w){if("touches"in p&&p.touches.length===2)return!c.current.allowPinchZoom;var g=ie(p),x=n.current,A="deltaX"in p?p.deltaX:x[0]-g[0],k="deltaY"in p?p.deltaY:x[1]-g[1],P,E=p.target,I=Math.abs(A)>Math.abs(k)?"h":"v";if("touches"in p&&I==="h"&&E.type==="range")return!1;var M=Xe(I,E);if(!M)return!0;if(M?P=I:(P=I==="v"?"h":"v",M=Xe(I,E)),!M)return!1;if(!o.current&&"changedTouches"in p&&(A||k)&&(o.current=P),!P)return!0;var z=o.current||P;return Dn(z,w,p,z==="h"?A:k,!0)},[]),l=r.exports.useCallback(function(p){var w=p;if(!(!N.length||N[N.length-1]!==s)){var g="deltaY"in w?Je(w):ie(w),x=t.current.filter(function(P){return P.name===w.type&&P.target===w.target&&Ln(P.delta,g)})[0];if(x&&x.should){w.preventDefault();return}if(!x){var A=(c.current.shards||[]).map(Qe).filter(Boolean).filter(function(P){return P.contains(w.target)}),k=A.length>0?i(w,A[0]):!c.current.noIsolation;k&&w.preventDefault()}}},[]),u=r.exports.useCallback(function(p,w,g,x){var A={name:p,delta:w,target:g,should:x};t.current.push(A),setTimeout(function(){t.current=t.current.filter(function(k){return k!==A})},1)},[]),h=r.exports.useCallback(function(p){n.current=ie(p),o.current=void 0},[]),m=r.exports.useCallback(function(p){u(p.type,Je(p),p.target,i(p,e.lockRef.current))},[]),y=r.exports.useCallback(function(p){u(p.type,ie(p),p.target,i(p,e.lockRef.current))},[]);r.exports.useEffect(function(){return N.push(s),e.setCallbacks({onScrollCapture:m,onWheelCapture:m,onTouchMoveCapture:y}),document.addEventListener("wheel",l,U),document.addEventListener("touchmove",l,U),document.addEventListener("touchstart",h,U),function(){N=N.filter(function(p){return p!==s}),document.removeEventListener("wheel",l,U),document.removeEventListener("touchmove",l,U),document.removeEventListener("touchstart",h,U)}},[]);var b=e.removeScrollBar,C=e.inert;return G(ze,{children:[C?$(s,{styles:Bn(a)}):null,b?$(In,{gapMode:"margin"}):null]})}const Nn=wn(lt,Un);var ht=r.exports.forwardRef(function(e,t){return $(he,{...F({},e,{ref:t,sideCar:Nn})})});ht.classNames=he.classNames;const Wn=ht;var Kn=function(e){if(typeof document>"u")return null;var t=Array.isArray(e)?e[0]:e;return t.ownerDocument.body},W=new WeakMap,ce=new WeakMap,ue={},Ae=0,ft=function(e){return e&&(e.host||ft(e.parentNode))},Yn=function(e,t){return t.map(function(n){if(e.contains(n))return n;var o=ft(n);return o&&e.contains(o)?o:(console.error("aria-hidden",n,"in not contained inside",e,". Doing nothing"),null)}).filter(function(n){return Boolean(n)})},Hn=function(e,t,n,o){var a=Yn(t,Array.isArray(e)?e:[e]);ue[n]||(ue[n]=new WeakMap);var s=ue[n],c=[],i=new Set,l=new Set(a),u=function(m){!m||i.has(m)||(i.add(m),u(m.parentNode))};a.forEach(u);var h=function(m){!m||l.has(m)||Array.prototype.forEach.call(m.children,function(y){if(i.has(y))h(y);else{var b=y.getAttribute(o),C=b!==null&&b!=="false",p=(W.get(y)||0)+1,w=(s.get(y)||0)+1;W.set(y,p),s.set(y,w),c.push(y),p===1&&C&&ce.set(y,!0),w===1&&y.setAttribute(n,"true"),C||y.setAttribute(o,"true")}})};return h(t),i.clear(),Ae++,function(){c.forEach(function(m){var y=W.get(m)-1,b=s.get(m)-1;W.set(m,y),s.set(m,b),y||(ce.has(m)||m.removeAttribute(o),ce.delete(m)),b||m.removeAttribute(n)}),Ae--,Ae||(W=new WeakMap,W=new WeakMap,ce=new WeakMap,ue={})}},qn=function(e,t,n){n===void 0&&(n="data-aria-hidden");var o=Array.from(Array.isArray(e)?e:[e]),a=t||Kn(e);return a?(o.push.apply(o,Array.from(a.querySelectorAll("[aria-live]"))),Hn(o,a,n,"aria-hidden")):function(){return null}};const gt="Dialog",[yt,Vo]=zt(gt),[jn,_]=yt(gt),Vn=e=>{const{__scopeDialog:t,children:n,open:o,defaultOpen:a,onOpenChange:s,modal:c=!0}=e,i=r.exports.useRef(null),l=r.exports.useRef(null),[u=!1,h]=Lt({prop:o,defaultProp:a,onChange:s});return r.exports.createElement(jn,{scope:t,triggerRef:i,contentRef:l,contentId:ye(),titleId:ye(),descriptionId:ye(),open:u,onOpenChange:h,onOpenToggle:r.exports.useCallback(()=>h(m=>!m),[h]),modal:c},n)},vt="DialogPortal",[Zn,wt]=yt(vt,{forceMount:void 0}),Xn=e=>{const{__scopeDialog:t,forceMount:n,children:o,container:a}=e,s=_(vt,t);return r.exports.createElement(Zn,{scope:t,forceMount:n},r.exports.Children.map(o,c=>r.exports.createElement(me,{present:n||s.open},r.exports.createElement(an,{asChild:!0,container:a},c))))},Ie="DialogOverlay",Jn=r.exports.forwardRef((e,t)=>{const n=wt(Ie,e.__scopeDialog),{forceMount:o=n.forceMount,...a}=e,s=_(Ie,e.__scopeDialog);return s.modal?r.exports.createElement(me,{present:o||s.open},r.exports.createElement(Qn,O({},a,{ref:t}))):null}),Qn=r.exports.forwardRef((e,t)=>{const{__scopeDialog:n,...o}=e,a=_(Ie,n);return r.exports.createElement(Wn,{as:Fe,allowPinchZoom:!0,shards:[a.contentRef]},r.exports.createElement(pe.div,O({"data-state":kt(a.open)},o,{ref:t,style:{pointerEvents:"auto",...o.style}})))}),J="DialogContent",eo=r.exports.forwardRef((e,t)=>{const n=wt(J,e.__scopeDialog),{forceMount:o=n.forceMount,...a}=e,s=_(J,e.__scopeDialog);return r.exports.createElement(me,{present:o||s.open},s.modal?r.exports.createElement(to,O({},a,{ref:t})):r.exports.createElement(no,O({},a,{ref:t})))}),to=r.exports.forwardRef((e,t)=>{const n=_(J,e.__scopeDialog),o=r.exports.useRef(null),a=Q(t,n.contentRef,o);return r.exports.useEffect(()=>{const s=o.current;if(s)return qn(s)},[]),r.exports.createElement(bt,O({},e,{ref:a,trapFocus:n.open,disableOutsidePointerEvents:!0,onCloseAutoFocus:Y(e.onCloseAutoFocus,s=>{var c;s.preventDefault(),(c=n.triggerRef.current)===null||c===void 0||c.focus()}),onPointerDownOutside:Y(e.onPointerDownOutside,s=>{const c=s.detail.originalEvent,i=c.button===0&&c.ctrlKey===!0;(c.button===2||i)&&s.preventDefault()}),onFocusOutside:Y(e.onFocusOutside,s=>s.preventDefault())}))}),no=r.exports.forwardRef((e,t)=>{const n=_(J,e.__scopeDialog),o=r.exports.useRef(!1);return r.exports.createElement(bt,O({},e,{ref:t,trapFocus:!1,disableOutsidePointerEvents:!1,onCloseAutoFocus:a=>{var s;if((s=e.onCloseAutoFocus)===null||s===void 0||s.call(e,a),!a.defaultPrevented){var c;o.current||(c=n.triggerRef.current)===null||c===void 0||c.focus(),a.preventDefault()}o.current=!1},onInteractOutside:a=>{var s,c;(s=e.onInteractOutside)===null||s===void 0||s.call(e,a),a.defaultPrevented||(o.current=!0);const i=a.target;((c=n.triggerRef.current)===null||c===void 0?void 0:c.contains(i))&&a.preventDefault()}}))}),bt=r.exports.forwardRef((e,t)=>{const{__scopeDialog:n,trapFocus:o,onOpenAutoFocus:a,onCloseAutoFocus:s,...c}=e,i=_(J,n),l=r.exports.useRef(null),u=Q(t,l);return un(),r.exports.createElement(r.exports.Fragment,null,r.exports.createElement(Jt,{asChild:!0,loop:!0,trapped:o,onMountAutoFocus:a,onUnmountAutoFocus:s},r.exports.createElement(Vt,O({role:"dialog",id:i.contentId,"aria-describedby":i.descriptionId,"aria-labelledby":i.titleId,"data-state":kt(i.open)},c,{ref:u,onDismiss:()=>i.onOpenChange(!1)}))),!1)});function kt(e){return e?"open":"closed"}const oo=Vn,ro=Xn,ao=Jn,so=eo;var et=1,io=.9,co=.3,Ee=.1,uo=0,Ce=.999,lo=.9999,po=.99,tt=/[\\\/\-_+.# \t"@\[\(\{&]/,mo=/[\\\/\-_+.# \t"@\[\(\{&]/g;function Re(e,t,n,o,a,s){if(s===t.length)return a===e.length?et:po;for(var c=o.charAt(s),i=n.indexOf(c,a),l=0,u,h,m;i>=0;)u=Re(e,t,n,o,i+1,s+1),u>l&&(i===a?u*=et:tt.test(e.charAt(i-1))?(u*=io,m=e.slice(a,i-1).match(mo),m&&a>0&&(u*=Math.pow(Ce,m.length))):tt.test(e.slice(a,i-1))?(u*=uo,a>0&&(u*=Math.pow(Ce,i-a))):(u*=co,a>0&&(u*=Math.pow(Ce,i-a))),e.charAt(i)!==t.charAt(s)&&(u*=lo)),u<Ee&&n.charAt(i-1)===o.charAt(s+1)&&n.charAt(i-1)!==o.charAt(s)&&(h=Re(e,t,n,o,i+1,s+2),h*Ee>u&&(u=h*Ee)),u>l&&(l=u),i=n.indexOf(c,i+1);return l}function ho(e,t){return Re(e,t,e.toLowerCase(),t.toLowerCase(),0,0)}var fo=ho,go='[cmdk-list-sizer=""]',Z='[cmdk-group=""]',xe='[cmdk-group-items=""]',yo='[cmdk-group-heading=""]',St='[cmdk-item=""]',nt=`${St}:not([aria-disabled="true"])`,Me="cmdk-item-select",D="data-value",vo=(e,t)=>fo(e,t),At=r.exports.createContext(void 0),ee=()=>r.exports.useContext(At),Et=r.exports.createContext(void 0),Ge=()=>r.exports.useContext(Et),Ct=r.exports.createContext(void 0),xt=r.exports.forwardRef((e,t)=>{let n=r.exports.useRef(null),o=K(()=>({search:"",value:"",filtered:{count:0,items:new Map,groups:new Set}})),a=K(()=>new Set),s=K(()=>new Map),c=K(()=>new Map),i=K(()=>new Set),l=Pt(e),{label:u,children:h,value:m,onValueChange:y,filter:b,shouldFilter:C,...p}=e,w=r.exports.useId(),g=r.exports.useId(),x=r.exports.useId(),A=$o();q(()=>{if(m!==void 0){let d=m.trim().toLowerCase();o.current.value=d,A(6,Le),k.emit()}},[m]);let k=r.exports.useMemo(()=>({subscribe:d=>(i.current.add(d),()=>i.current.delete(d)),snapshot:()=>o.current,setState:(d,v,S)=>{var f,T,R;if(!Object.is(o.current[d],v)){if(o.current[d]=v,d==="search")z(),I(),A(1,M);else if(d==="value")if(((f=l.current)==null?void 0:f.value)!==void 0){(R=(T=l.current).onValueChange)==null||R.call(T,v);return}else S||A(5,Le);k.emit()}},emit:()=>{i.current.forEach(d=>d())}}),[]),P=r.exports.useMemo(()=>({value:(d,v)=>{v!==c.current.get(d)&&(c.current.set(d,v),o.current.filtered.items.set(d,E(v)),A(2,()=>{I(),k.emit()}))},item:(d,v)=>(a.current.add(d),v&&(s.current.has(v)?s.current.get(v).add(d):s.current.set(v,new Set([d]))),A(3,()=>{z(),I(),o.current.value||M(),k.emit()}),()=>{c.current.delete(d),a.current.delete(d),o.current.filtered.items.delete(d),A(4,()=>{z(),M(),k.emit()})}),group:d=>(s.current.has(d)||s.current.set(d,new Set),()=>{c.current.delete(d),s.current.delete(d)}),filter:()=>l.current.shouldFilter,label:u||e["aria-label"],listId:w,inputId:x,labelId:g}),[]);function E(d){var f;var v;let S=(f=(v=l.current)==null?void 0:v.filter)!=null?f:vo;return d?S(d,o.current.search):0}function I(){if(!n.current||!o.current.search||l.current.shouldFilter===!1)return;let d=o.current.filtered.items,v=[];o.current.filtered.groups.forEach(f=>{let T=s.current.get(f),R=0;T.forEach(V=>{let oe=d.get(V);R=Math.max(oe,R)}),v.push([f,R])});let S=n.current.querySelector(go);j().sort((f,T)=>{var oe,We;let R=f.getAttribute(D),V=T.getAttribute(D);return((oe=d.get(V))!=null?oe:0)-((We=d.get(R))!=null?We:0)}).forEach(f=>{let T=f.closest(xe);T?T.appendChild(f.parentElement===T?f:f.closest(`${xe} > *`)):S.appendChild(f.parentElement===S?f:f.closest(`${xe} > *`))}),v.sort((f,T)=>T[1]-f[1]).forEach(f=>{let T=n.current.querySelector(`${Z}[${D}="${f[0]}"]`);T==null||T.parentElement.appendChild(T)})}function M(){let d=j().find(S=>!S.ariaDisabled),v=d==null?void 0:d.getAttribute(D);k.setState("value",v||void 0)}function z(){if(!o.current.search||l.current.shouldFilter===!1){o.current.filtered.count=a.current.size;return}o.current.filtered.groups=new Set;let d=0;for(let v of a.current){let S=c.current.get(v),f=E(S);o.current.filtered.items.set(v,f),f>0&&d++}for(let[v,S]of s.current)for(let f of S)if(o.current.filtered.items.get(f)>0){o.current.filtered.groups.add(v);break}o.current.filtered.count=d}function Le(){var d,v,S;let f=ne();f&&(((d=f.parentElement)==null?void 0:d.firstChild)===f&&((S=(v=f.closest(Z))==null?void 0:v.querySelector(yo))==null||S.scrollIntoView({block:"nearest"})),f.scrollIntoView({block:"nearest"}))}function ne(){return n.current.querySelector(`${St}[aria-selected="true"]`)}function j(){return Array.from(n.current.querySelectorAll(nt))}function fe(d){let v=j()[d];v&&k.setState("value",v.getAttribute(D))}function ge(d){var v;let S=ne(),f=j(),T=f.findIndex(V=>V===S),R=f[T+d];(v=l.current)!=null&&v.loop&&(R=T+d<0?f[f.length-1]:T+d===f.length?f[0]:f[T+d]),R&&k.setState("value",R.getAttribute(D))}function Be(d){let v=ne(),S=v==null?void 0:v.closest(Z),f;for(;S&&!f;)S=d>0?Po(S,Z):To(S,Z),f=S==null?void 0:S.querySelector(nt);f?k.setState("value",f.getAttribute(D)):ge(d)}let _e=()=>fe(j().length-1),Ue=d=>{d.preventDefault(),d.metaKey?_e():d.altKey?Be(1):ge(1)},Ne=d=>{d.preventDefault(),d.metaKey?fe(0):d.altKey?Be(-1):ge(-1)};return r.exports.createElement("div",{ref:te([n,t]),...p,"cmdk-root":"",onKeyDown:d=>{var v;if((v=p.onKeyDown)==null||v.call(p,d),!d.defaultPrevented)switch(d.key){case"n":case"j":{d.ctrlKey&&Ue(d);break}case"ArrowDown":{Ue(d);break}case"p":case"k":{d.ctrlKey&&Ne(d);break}case"ArrowUp":{Ne(d);break}case"Home":{d.preventDefault(),fe(0);break}case"End":{d.preventDefault(),_e();break}case"Enter":{d.preventDefault();let S=ne();if(S){let f=new Event(Me);S.dispatchEvent(f)}}}}},r.exports.createElement("label",{"cmdk-label":"",htmlFor:P.inputId,id:P.labelId,style:Oo},u),r.exports.createElement(Et.Provider,{value:k},r.exports.createElement(At.Provider,{value:P},h)))}),wo=r.exports.forwardRef((e,t)=>{let n=r.exports.useId(),o=r.exports.useRef(null),a=r.exports.useContext(Ct),s=ee(),c=Pt(e);q(()=>s.item(n,a),[]);let i=Tt(n,o,[e.value,e.children,o]),l=Ge(),u=H(g=>g.value&&g.value===i.current),h=H(g=>s.filter()===!1?!0:g.search?g.filtered.items.get(n)>0:!0);r.exports.useEffect(()=>{let g=o.current;if(!(!g||e.disabled))return g.addEventListener(Me,m),()=>g.removeEventListener(Me,m)},[h,e.onSelect,e.disabled]);function m(){var g,x;(x=(g=c.current).onSelect)==null||x.call(g,i.current)}function y(){l.setState("value",i.current,!0)}if(!h)return null;let{disabled:b,value:C,onSelect:p,...w}=e;return r.exports.createElement("div",{ref:te([o,t]),...w,"cmdk-item":"",role:"option","aria-disabled":b||void 0,"aria-selected":u||void 0,"data-selected":u||void 0,onPointerMove:b?void 0:y,onClick:b?void 0:m},e.children)}),bo=r.exports.forwardRef((e,t)=>{let{heading:n,children:o,...a}=e,s=r.exports.useId(),c=r.exports.useRef(null),i=r.exports.useRef(null),l=r.exports.useId(),u=ee(),h=H(y=>u.filter()===!1?!0:y.search?y.filtered.groups.has(s):!0);q(()=>u.group(s),[]),Tt(s,c,[e.value,e.heading,i]);let m=r.exports.createElement(Ct.Provider,{value:s},o);return r.exports.createElement("div",{ref:te([c,t]),...a,"cmdk-group":"",role:"presentation",hidden:h?void 0:!0},n&&r.exports.createElement("div",{ref:i,"cmdk-group-heading":"","aria-hidden":!0,id:l},n),r.exports.createElement("div",{"cmdk-group-items":"",role:"group","aria-labelledby":n?l:void 0},m))}),ko=r.exports.forwardRef((e,t)=>{let{alwaysRender:n,...o}=e,a=r.exports.useRef(null),s=H(c=>!c.search);return!n&&!s?null:r.exports.createElement("div",{ref:te([a,t]),...o,"cmdk-separator":"",role:"separator"})}),So=r.exports.forwardRef((e,t)=>{let{onValueChange:n,...o}=e,a=e.value!=null,s=Ge(),c=H(l=>l.search),i=ee();return r.exports.useEffect(()=>{e.value!=null&&s.setState("search",e.value)},[e.value]),r.exports.createElement("input",{ref:t,...o,"cmdk-input":"",autoComplete:"off",autoCorrect:"off",spellCheck:!1,"aria-autocomplete":"list",role:"combobox","aria-expanded":!0,"aria-controls":i.listId,"aria-labelledby":i.labelId,id:i.inputId,type:"text",value:a?e.value:c,onChange:l=>{a||s.setState("search",l.target.value),n==null||n(l.target.value)}})}),Ao=r.exports.forwardRef((e,t)=>{let{children:n,...o}=e,a=r.exports.useRef(null),s=r.exports.useRef(null),c=ee();return r.exports.useEffect(()=>{if(s.current&&a.current){let i=s.current,l=a.current,u,h=new ResizeObserver(()=>{u=requestAnimationFrame(()=>{let m=i.getBoundingClientRect().height;l.style.setProperty("--cmdk-list-height",m.toFixed(1)+"px")})});return h.observe(i),()=>{cancelAnimationFrame(u),h.unobserve(i)}}},[]),r.exports.createElement("div",{ref:te([a,t]),...o,"cmdk-list":"",role:"listbox","aria-label":"Suggestions",id:c.listId,"aria-labelledby":c.inputId},r.exports.createElement("div",{ref:s,"cmdk-list-sizer":""},n))}),Eo=r.exports.forwardRef((e,t)=>{let{open:n,onOpenChange:o,container:a,...s}=e;return r.exports.createElement(oo,{open:n,onOpenChange:o},r.exports.createElement(ro,{container:a},r.exports.createElement(ao,{"cmdk-overlay":""}),r.exports.createElement(so,{"aria-label":e.label,"cmdk-dialog":""},r.exports.createElement(xt,{ref:t,...s}))))}),Co=r.exports.forwardRef((e,t)=>{let n=r.exports.useRef(!0),o=H(a=>a.filtered.count===0);return r.exports.useEffect(()=>{n.current=!1},[]),n.current||!o?null:r.exports.createElement("div",{ref:t,...e,"cmdk-empty":"",role:"presentation"})}),xo=r.exports.forwardRef((e,t)=>{let{progress:n,children:o,...a}=e;return r.exports.createElement("div",{ref:t,...a,"cmdk-loading":"",role:"progressbar","aria-valuenow":n,"aria-valuemin":0,"aria-valuemax":100,"aria-label":"Loading..."},r.exports.createElement("div",{"aria-hidden":!0},o))}),X=Object.assign(xt,{List:Ao,Item:wo,Input:So,Group:bo,Separator:ko,Dialog:Eo,Empty:Co,Loading:xo});function Po(e,t){let n=e.nextElementSibling;for(;n;){if(n.matches(t))return n;n=n.nextElementSibling}}function To(e,t){let n=e.previousElementSibling;for(;n;){if(n.matches(t))return n;n=n.previousElementSibling}}function Pt(e){let t=r.exports.useRef(e);return q(()=>{t.current=e}),t}var q=typeof window>"u"?r.exports.useEffect:r.exports.useLayoutEffect;function K(e){let t=r.exports.useRef();return t.current===void 0&&(t.current=e()),t}function te(e){return t=>{e.forEach(n=>{typeof n=="function"?n(t):n!=null&&(n.current=t)})}}function H(e){let t=Ge(),n=()=>e(t.snapshot());return r.exports.useSyncExternalStore(t.subscribe,n,n)}function Tt(e,t,n){let o=r.exports.useRef(),a=ee();return q(()=>{var s;let c=(()=>{var i;for(let l of n){if(typeof l=="string")return l.trim().toLowerCase();if(typeof l=="object"&&"current"in l&&l.current)return(i=l.current.textContent)==null?void 0:i.trim().toLowerCase()}})();a.value(e,c),(s=t.current)==null||s.setAttribute(D,c),o.current=c}),o}var $o=()=>{let[e,t]=r.exports.useState(),n=K(()=>new Map);return q(()=>{n.current.forEach(o=>o()),n.current=new Map},[e]),(o,a)=>{n.current.set(o,a),t({})}},Oo={position:"absolute",width:"1px",height:"1px",padding:"0",margin:"-1px",overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",borderWidth:"0"};class $t{constructor(t,n){this.element=t,this.key=n,this.init()}get visible(){return this.element.style.display!=="none"}hide(){this.element.style.display="none",chrome.storage.local.set({[this.key]:!1})}show(){this.element.style.display="block",chrome.storage.local.set({[this.key]:!0})}async init(){(await chrome.storage.local.get([this.key]))[this.key]===!1&&this.hide()}toggle(){this.visible?this.hide():this.show()}}const Io=new $t(document.getElementsByClassName("srf-layout__footer")[0],"showFooter"),Ro=new $t(document.getElementsByClassName("srf-layout__sidebar")[0],"showMenu");function Mo(e){return{id:e.id,name:e.name,action:{type:"goto",payload:e.url},status:e.status,description:e.description,tags:e.tags}}const zo=[{type:"app",name:"Semrush Persona",id:"semrush-persona",url:"/apps/semrush-persona/",description:`The Semrush Persona is a free tool that helps you create unlimited buyer persona profiles for your business - with ease. You can either use the existing templates (for example, the B2B persona) or create your own personas from scratch. 

The templates are fully customizable: you can add various modules and create new ones. For example, you can choose to include demographic and professional information, goals and pain points, factors influencing buying decisions, etc.

Use this tool to save time and resources once your primary buyer persona research is complete. The visually attractive profiles that are easy to understand and remember can help transform your findings into meaningful insights. It\u2019ll help you ensure that everyone in your company is aware of your buyer personas (and is proactively using them to make business decisions). 

By the way, you can also use the in-app tips if you are not sure where to source data and/or how to put it into practice.`,tags:["Free","Semrush","Agencies","Small Business","Content Creation"],iconUrl:"https://static.semrush.com/app-center/apps_images/semrush-persona/Persona_app_logo.png",developer:"Semrush Inc."},{type:"app",name:"Local Listings Check",id:"local-listings-check",url:"/apps/local-listings-check/",description:`Scan your business now, and learn what you need to address to start improving your local online visibility. In order to build a robust local SEO strategy, it is important that your business has the right insights about its presence across all relevant directories in your area. With our help, you can achieve top-notch online visibility for your business today and start attracting more local customers to your door.

Get a snapshot of your local listings presence 

 - Quickly see the directories where your business needs to be listed for more local visibility. 
 - Get recommendations on how to improve your local listings, along with specific fixes that will improve your local search results. 
 - Get your average review ratings with our scan, and learn about our review management and map ranking tools. 

Check your business listings now.`,tags:["Free","Semrush","Agencies","Small Business"],iconUrl:"https://static.semrush.com/apps/static/Local%20Listings%20Check%20(free%20app)-EATY3U6ZJWJ44.png",developer:"Semrush Inc."},{type:"app",name:"Plagiarism Checker",id:"plagiarism-checker",url:"/apps/plagiarism-checker/",description:`Worried that your outsourced content is plagiarized? Does it read like a bot wrote it? Need grammar improvement suggestions? The Plagiarism Checker app checks for all these things.

Gain customer trust
Every business needs to earn the trust of its customers. One way to prove you're trustworthy is through the content you produce. Your content must feel natural and be easy for potential customers to read, so they can learn about your product and choose you over your competitors.

Stay credible
Plagiarized, AI-generated, and misspelled content can damage your credibility with customers and search engines. Google can penalize and de-rank a site if it detects stolen or AI-generated content. And customers are less likely to buy if they can't engage with your content because it's poorly written or full of errors.

And customers are less likely to make a purchase if they can\u2019t engage with your content because it\u2019s poorly written or full of errors.

Triple check your content
Check every piece of your content before it goes live. The Plagiarism Checker is here to help you:
\u2022 Check that the content is original
\u2022 Check if the content is AI-generated
\u2022 Check grammar and improve readability`,tags:["Free","Partners","Small Business","New","Content Creation"],iconUrl:"https://static.semrush.com/apps/static/plagiarism_checker_icon-KSY0NTCR8KJ6C.png",developer:"The Apps Cloud"},{type:"app",name:"Instant Keyword Research for Amazon",id:"instant-keyword-research-for-amazon",url:"/apps/instant-keyword-research/",description:`Instant Keyword Research for Amazon optimizes your Amazon product listings and helps you outdo the competition - for free. 

Uncover top keywords, data insights and metrics from your competitors and use them in your own SEO strategy for Amazon. Also find high quality keywords that can fast track your research process by seeing which bring your competition the best results.  

Here's what you can do:

1.  Automatically list your top Amazon competitors 
2. Research the competition and find highly relevant keywords 
3. Research keywords quickly and easily 
4. Explore organic search competitors
5. Analyze keyword search volume 
6. Curate high-performing keyword lists. 
7. Download your keywords as a .csv file or export them to your Keyword Manager for Amazon app.

Please note: At this time, Instant Keyword Research for Amazon only supports the Amazon U.S. Marketplace.`,tags:["Free","Semrush","Ecommerce","Competitor Analysis","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/IKR_256x256-5LV2U5Z2LI1N5.png",developer:"Semrush Inc."},{type:"app",name:"ImpactHero",id:"impacthero",url:"/apps/impact-hero/",description:`ImpactHero is an AI tool for marketing teams looking to make sense of their content performance data and boost content marketing ROI.

It helps you find content pages and content types that generate business results and develop ways to increase engagement and conversion.

Here\u2019s what you can do with ImpactHero:

- Find high-performing content and tailor it to funnel stages
- Access easy-to-understand analytics and dashboards created specifically for content marketers
- Get actionable insights on each content page to boost engagement and convert more users
- Identify the top-performing content formats and lengths.
- Pinpoint the most efficient traffic sources and optimize your strategy`,tags:["Semrush","Agencies","Small Business","Content Creation"],iconUrl:"https://static.semrush.com/app-center/apps_images/impact-hero/Imact_Hero_app_logo.png",developer:"Semrush Inc."},{type:"app",name:"Agency Growth Kit",id:"agency-growth-kit",url:"/apps/agency-growth-kit/",description:`The Agency Growth Kit is a set of tools designed to help agencies find, win, and retain more clients.

Here\u2019s what is available to you in the Agency Growth Kit:

1. Agency Partners Platform: Get an instant flow of new inbound leads
Build trust with your clients and prospects by becoming a Semrush Agency Partner. As an Agency Partner, you\u2019ll receive a personal listing page on our Agency Partners platform, helping you land more clients.

2. Bid Finder: Target high-revenue marketing bids and win new clients
Find and win new, relevant opportunities before the competition. With Bid Finder, you can search for marketing bids by:
- Topic;
- Location; 
- Publication date;
- Deadline;
- Total value.
Then receive automated alerts whenever a new bid matching your search criteria is published, so you can pitch to them first.

3. CRM: Maintain a more seamless workflow with enhanced client management 
Manage your prospects, leads, and clients more efficiently, so you can focus on helping them more effectively. With Semrush CRM, you can:
- Evaluate prospects and leads in-depth with enriched data;
- Maintain and organize key client information, including budgets, contact details, and statuses;
- Track multiple Semrush projects for individual clients;
- Quickly collect data and create engaging, personalized pitches and reports;
- Share reports 24/7 with individual, secure, interactive client portals.

4. Client Portal: Share reports and tasks 24/7 with interactive, secure white-label portals
Enable your clients to access their most up-to-date reports and tasks around the clock with the Client Portal feature. In a few clicks, create interactive, password-protected portals for each client. Then select the reports you want to showcase and arrange for them to update automatically on a daily, weekly, or monthly basis.


5. Advanced reporting: Create beautiful, personalized reports for each of your clients 
Integrate data from Semrush, Google Analytics, Google GA4, Google Search Console, and Google My Business to build customized reports for your clients. Then personalize them with features like:
- Custom fonts, colors, and backgrounds;
- Custom logos (yours or your clients\u2019) on every PDF report you schedule or download from Semrush;
- White-label reports.`,tags:["Semrush","Agencies","Analytics & Reports"],iconUrl:"https://static.semrush.com/app-center/apps_images/agency-growth-kit/Agency_Growth_Kit_app_logo.png",developer:"Semrush Inc."},{type:"app",name:"Semrush .Trends",id:"semrush--trends",url:"/apps/semrush-trends/",description:`Semrush .Trends helps businesses to reveal market trends and competitive insights \u2014 for any website, industry or market, for 190 countries.

Its reliable and comprehensive data empowers you to:
- Identify untapped market opportunities and get a larger market share
- Discover top-priority channels for higher business impact
- Make data-driven marketing strategy improvements to increase ROI

Semrush .Trends includes:

Market Explorer \u2014 a comprehensive market overview with a list of top players and their market share, key industry trends, audience characteristics, and more. Examine the growth dynamics of your closest competitors.

Traffic Analytics \u2014 performance overview of any website, with a channel-by-channel breakdown, including traffic acquisition priorities \u2014 direct, referral, search, social, or paid traffic \u2014 and insights on its traffic sources, top pages, engagement, and website metrics. Understand the digital marketing strategies of any competitor.`,tags:["Semrush","Agencies","Competitor Analysis"],iconUrl:"https://static.semrush.com/app-center/apps_images/semrush-trends/Semrush_Trends_app_logo.png",developer:"Semrush Inc."},{type:"app",name:"Map Rank Tracker",id:"map-rank-tracker",url:"/apps/map-rank-tracker/",description:`Get in the coveted Map Pack with the right local analytics. Get the information necessary to place your business at the top of Google Maps and Search. Be the business that people choose by successfully optimizing your local keywords, ratings, and review strategies to rank high within the Map Pack. 

1) Get a 360 view of your local search and map rankings  
 - Quickly see how you rank for target keywords in your chosen area of Google Maps. 
 - Easily check your Google Maps rankings across all your locations, and find out if you are placing in the Map Pack.
 - Access historical map rankings and quickly spot improvements or any other type of change. 

2) Spy on your competitors to better optimize your strategy
 - See how you stack up against your local competitors with crucial keywords using our Heatmap. 
 - Get a complete picture of your competitors\u2019 ratings, reviews and ranking to see where you need to improve. 

3) Check the health of your listings presence for optimal visibility
 - Get key insights from your Google Business Profile\u2014on the views, number of search and map appearances in your profile.
 - Ensure consistency across 70+ local listings for better local search ranking, and get actionable insights on how to improve them.

4) Monitor your online reputation 
 - Monitor and respond to customers\u2019 reviews.
 - Keep track of your star ratings, reviews, and progress to accurately assess your reputation. 
 - Quickly spot areas of improvement to strengthen your local branding.`,tags:["Semrush","Agencies","Small Business","Competitor Analysis","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/Map%20Rank%20Tracking-9LTHL027UUEQ4.png",developer:"Semrush Inc."},{type:"app",name:"Review Management",id:"review-management",url:"/apps/review-management/",description:`Own the conversation, engage with customers, and see where opportunity lies with our Review Management app. Businesses cannot ignore reviews in today's digital age, and can drastically increase business with little effort if they have the right tools to leverage them.

1) Monitor all reviews from a single platform 
 - Track 70+ directories and respond quickly to reviews in top listings, including Google, Facebook, and Yelp.
 - Obtain a high response rate and level of engagement with active listings that connect customers to you.

2) Easily safeguard your brand
 - Be alerted immediately to bad reviews, and defuse them quickly with the right responses.
 - Build loyalty and win new customers by cultivating a healthy crop of good reviews.
 - Get a complete overview of how your ratings stand over time with our bar graph tab.

And more analytics to help you rank better in local search:

3) Get more visibility and outrank your competitors 
 - Place your business in the top directories, and see where improvements can be made.
 - See how you compare against your local competitors with important keywords in search. 
 - Get insights on the performance of your Google Business Profile (i.e. number of views, search, map appearances) and easily spot areas for optimization.`,tags:["Semrush","Agencies","Small Business","Media Monitoring"],iconUrl:"https://static.semrush.com/apps/static/Review%20Management-B45XY4HCBDMAL.png",developer:"Semrush Inc."},{type:"app",name:"Semrush Local",id:"semrush-local",url:"/apps/local-seo/",description:`Businesses that rank higher locally get more searches, clicks, visits, and have more opportunities to make a sale. Semrush Local provides businesses with the tools and data that they need to put themselves in front of prospective local customers in search of their product or services. 

1. Automatically list and manage 70+ top directories
 \u2022 Join the thousands of businesses that are finding new customers by adding their business NAP (name, address, phone) to top listings
 \u2022 Quickly place your business information across applications, maps, aggregators and search engines across the world (i.e. Google, Facebook, Bing and Yelp) 
 \u2022 Create a comprehensive Google Business Profile, and handle multiple locations through one platform.
 \u2022 Create complete listings with logos, photos and videos to ensure greater visibility, and make your business more appealing to customers.
 \u2022 Eliminate confusion, by keeping your business information consistent, and suppressing duplicate listings.
 \u2022 Get recommendations (including real-time user suggestions) and corrections in one place for optimal maintenance and performance.

2. Monitor and respond quickly to all reviews from a single platform
 \u2022 Respond quickly to reviews in top directories, such as Google, Facebook, and Yelp.
 \u2022 Obtain a high response rate, and encourage more reviews from customers
 \u2022 Be alerted daily to bad reviews, and defuse them quickly with the right responses.
 \u2022 Cultivate a healthy crop of good reviews to build loyalty and win new customers.
 \u2022 Get an overview of your reviews, and see where action needs to be taken for improvement 

3. Get a 360 overall view of your local search & map rankings  
 \u2022 Quickly see how you rank for target keywords in your chosen areas of Google Map 
 \u2022 Easily check your Google Map rankings across all your locations, and find out if you are placing in the coveted Map Pack
 \u2022 See how you stack up against your local competitors with ratings, reviews and rank, to better optimize your position goals`,tags:["Semrush","Agencies","Small Business"],iconUrl:"https://static.semrush.com/apps/static/LM-Logo%20-%20256-DAYZN8ARH1WZY.png",developer:"Semrush Inc."},{type:"app",name:"Ecommerce Booster",id:"ecommerce-booster",url:"/apps/ecommerce-booster/",description:`Tired of endless DIY Shopify store audits, intense competition, and unclear business growth points?

Ecommerce Booster has your back. The app runs a comprehensive audit of your store and creates an action plan with detailed instructions to make your product pages sell better. Its built-in AI tools help improve your content and images in minutes.

1. Get recommendations on visual and text content, user experience, page speed, and accessibility on your site to boost its performance: 

\u2022 Visual content: assess and enhance images on your product page to thrive in today's visual economy
\u2022 User experience: improve page layout and add necessary elements to boost your conversion rate 
\u2022 Text content: use the product description generator to improve the content on your page quickly
\u2022 Page speed and accessibility: ensure lightning-speed loading and excellent performance of your site

2. Get a clear plan of improvements to increase your online store sales

\u2022 Enter your domain and get the audit in one click
\u2022 Get your to-do list of prioritized actions needed to improve your website
\u2022 Use the product view to work on your top-performing pages first
\u2022 Each task has detailed instructions; no need for additional research or "translating from tech to human"

3.  Built-in AI tools and clear prioritization to increase your return on time and effort invested

\u2022 Use \u26A1\uFE0FAI Boost for instant improvement\u2014get the vital text and visual content tasks done in just five minutes with our built-in AI tools
\u2022 Prioritize the tasks and manage them quickly to find the biggest growth points and make time for what's most important: your business
\u2022 Consistency is key to success: Keep the streak going with a progress tracker that updates as you complete your tasks
\u2022 Schedule your audit for weekly updates on the most severe issues or on your top-performing pages to stay on top of things`,tags:["Semrush","Ecommerce","Small Business","New","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/EcommerceBooster_icon_256x256-5HHFYA8SAXMJ.png",developer:"Semrush Inc."},{type:"app",name:"EyeOn",id:"eyeon",url:"/apps/eyeon/",description:`Do you constantly wonder what your competitors are up to? Want to leverage their strategies to enhance your own digital marketing game?

EyeOn is here to help. This competitive tracking tool offers insights into your rivals' content and advertising activities, so you can stay ahead of the competition and dominate your market.

Get an in-depth view of your competitors' activity trends:

\u2022 Monitor your competitors' websites, blogs, and social media platforms in real time
\u2022 Track new blog posts and pages for insights into competitor content strategies
\u2022 Follow rivals\u2019 social media activity, growth, and engagement to better understand market audiences

Refine and enhance your own digital marketing strategies by keeping a close eye on the competition. The insights you gain from EyeOn will help you understand what works in your industry, allowing you to make data-driven decisions and stay ahead of your competitors.

Discover the power of competitive tracking for your business. Try EyeOn today!`,tags:["Semrush","Small Business","New","Competitor Analysis","Advertising"],iconUrl:"https://static.semrush.com/apps/static/256-13C13CC45GWMC.png",developer:"Semrush Inc"},{type:"app",name:"ContentShake",id:"contentshake",url:"/apps/contentshake/",description:`ContentShake is an all-in-one content writing tool you can use to create quality content that clicks with your customers.

It guides you from ideation to publishing directly to the blog, suggests personalized content ideas, composes copy with AI, and helps you optimize copy for engagement and rankings.

It\u2019s powerful yet easy to use and requires no special skills or extra research.

Content idea generation

\u2022 Get topic ideas based on your audience\u2019s real-life questions
\u2022 See what performs best for other websites in your niche
\u2022 Select ideas that generate the most traffic and are less competitive

Content writing

\u2022 Choose the best keywords and outlines for your articles 
\u2022 Get suggestions on creating engaging headlines and intros 
\u2022 Enrich your copy with relevant facts, statistics, and images
\u2022 Write content faster with advanced AI technology

Content optimization

\u2022 Get a score based on how well your copy is optimized 
\u2022 Rewrite bits of text that need to be improved in one click
\u2022 Make your copy more engaging to keep users and search engines happy

Collaboration and content management 

\u2022 Send your articles to Google Docs and share them with anyone
\u2022 Publish them directly to WordPress without leaving the tool
\u2022 See all of your articles and track progress in one place`,tags:["Semrush","Small Business","Content Creation","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/ContentShake%E2%80%93icon-DCTVP7IFVNE8.png",developer:"Semrush Inc."},{type:"app",name:"Product Feed Health Checker",id:"product-feed-health-checker",url:"/apps/product-feed-health-checker/",description:`Be sure your e-commerce product listings are optimized for Google\u2019s shopping feed with Product Feed Health Checker.

It allows you to:

1. Optimize your content for organic and paid (PLA) Google product feeds with our data-driven recommendations and get tips on improving visibility and reach
2. Use the most relevant keywords. Find the ideal keywords for your product pages whilst avoiding content overlaps with other products
3. Build top-performing product pages for Google Shopping and secure top places in Google\u2019s product feed.`,tags:["Semrush","Ecommerce"],iconUrl:"https://static.semrush.com/apps/static/FHC_256x256-IR0H6PEPGDPZ1.png",developer:"Semrush Inc."},{type:"app",name:"Competitor Tracker for Amazon",id:"competitor-tracker-for-amazon",url:"/apps/competitor-tracker-for-amazon/",description:`Stay on top of your game with The Competitor Tracker for Amazon app. 

With an intuitive and simple set up and reporting, the app allows Amazon Sellers to:  

Follow organic and sponsored ratings of competitor listings and stay up-to-date with product listing changes by your competitors. Also access clear weekly reports with everything you need to optimize your Amazon products

The Competitor Tracker for Amazon app helps you: 

1. Improve strategy and automate competitor research 

Use any ASIN or URL to follow the performance of product listings in weekly emails.

2. Track competitor sales, ads, and search rankings

Stay on top of changes with competitor products. Improve your own listings and discover opportunities

3. Uncover key competitor data insights 

Receive a clear report with everything you need to optimize your Amazon product listings.`,tags:["Semrush","Agencies","Ecommerce","Small Business","Competitor Analysis"],iconUrl:"https://static.semrush.com/apps/static/ACT_256x256%20(1)-HBX2T7H0UXTA0.png",developer:"Semrush Inc."},{type:"app",name:"Keyword Manager for Amazon",id:"keyword-manager-for-amazon",url:"/apps/keyword-manager-for-amazon/",description:`Store your keywords in one place with the Keyword Manager for Amazon app. 

Use it as part for your keyword research process, alongside the Keyword Wizard for Amazon and Instant Keyword Research for Amazon features.


1. Organize and keep track of all your keywords across various apps in one place. 
2. Get an in-depth analysis of up to 1,000 keywords at a time.
3. See the search volume and competition metrics for updates. Get real-time metrics covering SERP Features, Key word difficulty and Top Competitors.
4. Sort and export the lists of keywords that you need. Filter by keyword, databases, SERP features, search intent, tags, or by a specific metric, then export the report for the filtered group, or send the data to other tools.`,tags:["Semrush","Ecommerce"],iconUrl:"https://static.semrush.com/apps/static/AKM_256x256-ENYKZWYB6IXIM.png",developer:"Semrush Inc."},{type:"app",name:"Listing Alerts for Amazon",id:"listing-alerts-for-amazon",url:"/apps/listing-alerts-for-amazon/",description:`With Listing Alerts, Amazon sellers get instant notifications whenever there is a change in their listing.

With our app, you:

1. Get a 24/7 automated monitoring system 
2. Can track Amazon rankings, keyword positions, buy box statuses, prices, and listing suppression
3. Ensure that you don\u2019t lose traffic or potential sales. 
4. Can respond to changing situations and take back control over listings when needed. 
5. Follow competitor listings and get insights into their product strategies 
6. Track rankings and visibility.`,tags:["Semrush","Agencies","Ecommerce","Small Business","Media Monitoring"],iconUrl:"https://static.semrush.com/apps/static/logo-GG2ZXB1YUT2O5.png",developer:"Semrush Inc."},{type:"app",name:"Brand Monitoring",id:"brand-monitoring",url:"/apps/brand-monitoring/",description:`Use the Brand Monitoring app to track all your brand mentions across the web, estimate the value of your media coverage and much more. 

Set up detailed queries to track brands (yours, competitors' or others'), people, keywords, authors or backlinks. Brand Monitoring will find mentions for your query from news sites and many more, which you can filter in multiple ways to see relevant results, without the extra noise. 

The Brand Monitoring app can also be used to find relevant articles and authors for SEO and PR outreach by searching for keywords that you're interested in.

Each news hit contains a variety of insightful metrics that you can use as a filter or to assess the value of each mention, such as:
- sentiment
- domain authority
- estimated reach
- date
- backlinks

You can use these metrics to estimate the value of your media coverage or find hidden opportunities to secure additional backlinks to your website.

Additionally, you can filter mentions with parameters such as: 
- language 
- country 
- article category 
- domain category 
- and more 

Set up recurring digests and custom alerts right in the app and get notified about new mentions. Use this knowledge to summarize your coverage or quickly react to mentions with negative sentiment. 

The Brand Monitoring app contains an advanced and intuitive dashboard with multiple charts, such as: - mentions over time 
- mentions by country 
- categories of mentions 
- and much more`,tags:["Semrush","Small Business","Media Monitoring"],iconUrl:"https://static.semrush.com/apps/static/news%20alerts%20icon-9B9NSL21JULV.png",developer:"Prowly"},{type:"app",name:"Product Research for Amazon",id:"product-research-for-amazon",url:"/apps/product-research-for-amazon/",description:`Product Research for Amazon give you the tools you need to find in-demand products with low competition.  

Particularly useful for resellers, this app gives you:

1. Up-to-the-minute information on product demand, sharing you everything you need to know to make the right decisions for your store 
2. The chance to discover the most profitable products see similar listings based on keywords, category, or selling price.
3. The ability to forecast your return on investment with intuitive calculators. See if a product has the potential to make the profits you expect.`,tags:["Semrush","Ecommerce","Small Business","Competitor Analysis"],iconUrl:"https://static.semrush.com/apps/static/logo-E9CNJMSM7I88Y.png",developer:"Semrush Inc."},{type:"app",name:"Listing Quality Check for Amazon",id:"listing-quality-check-for-amazon",url:"/apps/listing-quality-check-for-amazon/",description:`The Listing Quality Check for Amazon app offers a full audit for your listings, helping you ensure they are compliant with Amazon\u2019s requirements and style guides.

Use it to:

1. Avoid suspension threats
2. Spot content errors and ensure your listings are complete
3. Stay totally aligned with Amazon guidelines
4. See recommendations and best practices
5. Access the quality score for your listing
6. Get expert and data-driven ideas for further optimization and better conversion rates
7. Analyze the quality of your competitors\u2019 listings and find new opportunities by comparing your results`,tags:["Semrush","Ecommerce","Small Business","Content Creation"],iconUrl:"https://static.semrush.com/apps/static/logo-77985VW4HPTO1.png",developer:"Semrush Inc."},{type:"app",name:"Keyword Wizard for Amazon",id:"keyword-wizard-for-amazon",url:"/apps/keyword-wizard-for-amazon/",description:`Amazon sellers can optimize their product listings with The Keyword Wizard for Amazon app.

Get access to keyword data boost your rankings to appear the first page of Amazon search results.

The Keyword Wizard for Amazon app helps you:

1. Increase your ranking with high quality database of 200+ mln keywords
2. Discover keywords with high-volume and low-competition terms
3. Filter by volume, competition, products catgory and number of words 
4. Find""Hidden Search Term"" field keywords and optimize your listing 
5. See how keyword search volumes change month by month
6. Check Keyword Difficulty of your search queries
7. Export your results to .csv or send them to Keyword Manager for Amazon app to manage and organize your keyword lists`,tags:["Semrush","Agencies","Ecommerce","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/logo-27YHVX6KJTS5L.png",developer:"Semrush Inc."},{type:"app",name:"Traffic Insights for Amazon",id:"traffic-insights-for-amazon",url:"/apps/traffic-insights-for-amazon/",description:`The Traffic Insights for Amazon app helps sellers see external traffic sources for product listed in the Amazon US store.

Data-driven insights from the tool will help you enhance your marketing efforts and better direct your strategy. Increase your potential for growth and have a clear idea of product-market fit.  

It allows you to:

1. Find new sources of customers
2. Discover the biggest external drivers of traffic
3. See customer numbers
4. Access Amazon seller central data (US)
5. Come to understand competitor strategies
6. Learn how to expand your reach beyond Amazon.`,tags:["Semrush","Agencies","Ecommerce","Competitor Analysis"],iconUrl:"https://static.semrush.com/apps/static/logo-57EUS9BK17ZZ4.png",developer:"Semrush Inc."},{type:"app",name:"Search Insights for Amazon",id:"search-insights-for-amazon",url:"/apps/search-insights-for-amazon/",description:`The Search Insights for Amazon app helps Amazon sellers increase their product\u2019s visibility in the search results. It provides the competitive insights you need to optimize your product pages effectively. 

It allows you to:

1. Work from insights to improve Amazon search visibility
2. Look into the data for up to three products (through ASIN or URL) and boost your product\u2019s brand exposure with the most profitable keywords.
3. See and understand your competitors\u2019 keyword strategy. Discover details top drivers of traffic,  
which special results it won (Amazon\u2019s Choice, Editorial Recommendations,etc.).
4. Analyze ANY Amazon product in the US marketplace and delve into how customers search for it. You'll see exactly how much organic traffic it gets and from which keywords. 
5. Identify top Amazon keywords by traffic
6. Compare product reach and Amazon search positions by keyword
7. Send new keywords to Keyword Manager for Amazon app to manage and organize them.`,tags:["Semrush","Agencies","Ecommerce","Competitor Analysis"],iconUrl:"https://static.semrush.com/apps/static/ATI_256x256-1BSCYAKMNA7F0-DA495ORXTLBN0.png",developer:"Semrush Inc."},{type:"app",name:"PPC Optimizer for Amazon",id:"ppc-optimizer-for-amazon",url:"/apps/ppc-optimizer-for-amazon/",description:`PPC Optimizer automates your Amazon ad campaigns, factoring in a lot of advertising aspects you might miss for making the right bidding decision.

\u{1F4A1} Think ROI, and not just ACoS

PPC Optimizer takes your basic specs and automatically creates four separate campaigns that find the top strategy for advertising your product. This way, the tool optimizes your campaign on the go, changing keywords, product targetings, and even bidding strategies\u2014all to meet your entered specs (target ACoS, total budget, and duration). 

\u{1F3AE} Fully auto or under your control: it\u2019s your choice!

\u0421hoose how involved you want to be in a campaign: our app can automatically pick the top keywords to target, or, you can manually enter the keywords and negatives for your campaign.

\u{1F512} Sales are important. So is your privacy

When setting up the tool, you will have to connect your Amazon account. We only use the data needed to run ad campaigns and have no access to your financials, customers, or products. 

We employ Semrush\u2019s strict data privacy protocols to make sure your data is safe with us.`,tags:["Semrush","Ecommerce","Small Business","Advertising"],iconUrl:"https://static.semrush.com/apps/static/PPC_256x256-K8W111F279CZG.png",developer:"Semrush Inc."},{type:"app",name:"Automated Data Connector",id:"automated-data-connector",url:"/apps/automated-data-connector/",description:`Export data from applications such as Salesforce, Trello, HubSpot, or Zendesk into Google Sheets and data warehouses in a few clicks.

Forget copy/paste and the CSV slog. Build the reports and dashboards you want in the fastest and most flexible way.

Using Automated Data Connector, you can automatically import all of your data into one place in Google Sheets. Build custom dashboards & reports and query, join, sync, and manipulate your data. 

\u2022 Farewell to manual exports and welcome to real-time data refresh without the need for coding 
\u2022 Free yourself from the tedious task of copying and pasting data repeatedly
\u2022 Make data actionable by keeping the team informed with Slack and email notifications

Features:

\u{1F539}Click Connections
Connect to your systems in one click. Pull your data instantly into Google Sheets.

\u{1F539}Customizable Imports
Work with only the data you need. Filter, sort, & limit any data set.

\u{1F539}Auto-Refreshes
Never build the same report twice! Automatically refresh your data on your preferred schedule (hourly, daily, or weekly). Share reports so team members across your organization will have refreshed data.

\u{1F539}Alerting
Track the signals you care about. Trigger Slack & email notifications to your team on any changes in your data. 

\u{1F539}Prebuilt Dashboards
Leverage prebuilt dashboards to effortlessly monitor and analyze your data. Drill down to company, team, individual, region, and more; view comparisons over previous periods; and customize to your needs.

\u{1F539}Cloud Joins and Pivot Tables
Join data sets from two or more sources, and make large data sets usable in your spreadsheet.`,tags:["Partners","Agencies","Analytics & Reports","New"],iconUrl:"https://static.semrush.com/apps/static/icon2_256-AFF07I5475HK0.png",developer:"Conduit"},{type:"app",name:"Landing Page Builder",id:"landing-page-builder",url:"/apps/landing-page-builder/",description:`Landing pages are a well-known marketing strategy to get more conversions from the same traffic.

Our Landing Page Builder is a one-stop shop for tech-savvy marketers who value their time and independence. Under one roof, you can quickly create, optimize, and launch hundreds of landing pages, bringing you or your clients more business. 


Build on-brand landing pages 
Landing Page Builder simplifies the process of creating high-converting landing pages.
Our users\u2019 TOP 5 features list includes:
\u25CF drag\u2019n\u2019drop and pixel-perfect builder
\u25CF manageable Mobile View and Thank You Page
\u25CF tons of free assets like icons, images, and predefined elements
\u25CF funnel and form creator for a better lead gen 
\u25CF changelog (if you need to restore your previous work)

Scale your work with Smart Sections
If you want to use the same element on many landing pages and be sure that even the slightest change implemented in one place will show up on every other landing page, use Smart Section. Smart Section can help you with the following:
\u25CF speed up the creation process
\u25CF build section templates
\u25CF update many landing pages with one click 
No more copy and paste!  Smart, isn\u2019t it? 

Optimize conversion rates. Get more leads!
Use different tactics depending on how you want to increase conversion rates:
\u25CF build personalized landing pages tailored to your audience\u2019s age, gender, location, interest, or traffic source
\u25CF optimize landing page details using A/B testing, headers, images, or CTAs
\u25CF test different landing pages and choose the best communication strategy for your campaign

Stay connected with the MarTech ecosystem
Let your apps talk to each other. Browse our extensive catalog with three types of integrations:
\u25CF in-app (easy authentication)
\u25CF compatible (using code snippets)
\u25CF Zapier (connect your forms via Zapier)
Connect the apps you already use or find new ones to enhance your marketing processes.

Use reliable infrastructure
You and your clients deserve safe cloud solutions. We deliver: 
\u25CF infrastructure based on Amazon Web Services 
\u25CF software and libraries update policy 
\u25CF SSLs and GDPR compliance`,tags:["Partners","Agencies","New","Advertising","Web Design"],iconUrl:"https://static.semrush.com/apps/static/landing_page_builder_app_icon-DJYVLONB5FGEA.png",developer:"Landingi"},{type:"app",name:"SERP Gap Analyzer",id:"serp-gap-analyzer",url:"/apps/serp-gap-analyzer/",description:`Do you ever feel like keyword research is like playing whack-a-mole?

Do you have a massive spreadsheet full of possible keywords to target, but are unsure which ones will move the needle fastest?

Don\u2019t break a sweat
SERP Gap Analyzer gives you an actionable list of keyword recommendations based on specific problems in SERP, designed to help you hit the ground running and provide an immediate boost to organic traffic.

Discover low-competition keywords tailormade for your site
SERP Gap Analyzer finds keywords to target based on weaknesses and gaps in the current top-10 SERP results for a keyword, such as:  
\u2022 Low Authority Score sites with not a lot of pages or posts
\u2022 Title tag mismatch with search intent
\u2022 Poor readability score
\u2022 Outdated content
\u2022 Slow load time
\u2022 Forum and social media results

Update existing content to rank higher 
Get unstuck in the SERPs and move up the results page faster by addressing specific flaws and issues with your content with specific recommendations for: 
\u2022 Search intent mismatch
\u2022 Thin content warnings
\u2022 Headline rewrites for better clickthrough rates
\u2022 Technical fixes, such as page load speeds
\u2022 Adding specific subtopics and semantically related keywords to your content

Leverage topical depth analysis for highly-specific cluster mapping
Understand your website\u2019s specific area of expertise and use that to spread your wings into related topics and queries. 

Our SERP gap engine finds underserved seed topics and breaks them down into keyword recommendations, highlighting specific issues and gaps that you can use to outrank the competition.`,tags:["Partners","Agencies","New","Competitor Analysis","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/SERP%20Gap%20Analyzer-AOLKTP3WDUIU7.png",developer:"TopicRanker"},{type:"app",name:"Ad Assistant",id:"ad-assistant",url:"/apps/ad-assistant/",description:`To monitor the performance of advertising campaigns, you need to spend a lot of time at the computer, jumping from one platform to another. And the more clients you have, the more time and attention it takes.

So what happens when you need to step away from your desk? If you\u2019re outside the office, on vacation, or simply away from the computer, it\u2019s difficult to stay on top of all your ad campaigns.

Missing an important detail could affect their performance, resulting in clients who are dissatisfied and who may start looking for better services. 

Ad Assistant helps you quickly monitor the effectiveness of ads wherever you are.

With Ad Assistant, you can:
- Control your Google, Microsoft, Facebook, Instagram, Twitter, and TikTok ads from the palm of your hand
- Get instant notifications when accounts need attention
- Optimize on the go`,tags:["Partners","Agencies","Advertising"],iconUrl:"https://static.semrush.com/apps/static/Clever%20Ads%20logo-8V9PGGV1Y7VFF.png",developer:"Clever Ads"},{type:"app",name:"BuzzGuru Influencer Analytics",id:"buzzguru-influencer-analytics",url:"/apps/buzzguru-influencer-marketing-platform/",description:`BuzzGuru is an all-in-one influencer marketing platform that lets you manage your entire influencer marketing campaign cycle in one place. It\u2019s the perfect combination of features & tools for preparing, running, and evaluating a creator campaign.

All the essentials, nothing useless.

Competitor Intelligence
- Evaluate competitors\u2019 ad campaign budgets
- Perform market and trends analysis
- Discover the influencers leading brands work with on a sponsored or free basis
- Learn about the preferred dates and time of promotion
- Discover videos promoting or mentioning a particular app, game, or website

Influencer Discovery
- 30+ data breakdowns and smart search filters
- Influencers\u2019 profiles with the most up-to-date data
- Sort influencers according to your specific needs, and group them in lists

Reporting & Analysis
- Get reports on your advertising campaigns automatically
- Visualize data and performance metrics in organized charts and tables
- Compare the campaign\u2019s result to your KPIs
- Get data-based performance forecasts
- Save time with automated calculations

Campaign Management
- Create a media plan for your campaign
- Manage team and data access
- Track and analyze influencers\u2019 content and performance
- Get a detailed campaign report

Let\u2019s make influencer marketing an accessible and effective user acquisition channel for you. Get the all-in-one software ecosystem to automate most of the tasks and make the world talk about your brand.`,tags:["Partners","Agencies","Most Popular","Competitor Analysis","Social Media"],iconUrl:"https://static.semrush.com/apps/static/buzzguru-influencer-analytics-icon-DHOG0N9REJXU5.png",developer:"BuzzGuru"},{type:"app",name:"Instant Video Creator",id:"instant-video-creator",url:"/apps/instant-video-creator/",description:`No time, budget, or ideas for video content? We\u2019ve got your back! The Instant Video Creator app automatically generates videos from your blog posts in seconds. Just enter the article URL and click generate. We\u2019ll use your article\u2019s headings, text, and images to create a unique video for your audience to like and share. You can even choose one of several realistic and professional AI voiceovers to read your text aloud.

What type of videos can you make? 
We give you complete flexibility to customize and edit your video as you like. For example, you can create the following:

\u2022 Blog post teasers that share the introduction to an article and prompt readers to visit your website for the complete text. 
Video testimonials that give life and voice to written reviews or case studies.
\u2022 Announcements that share feature updates or job postings in a more engaging format
\u2022 How-to video guides that convert your marketing, training, and support manuals into learning videos
\u2022 Q&A videos from existing or new FAQs and interview text

It\u2019s totally up to you. You can make a video from any snippet of written text from anywhere on the internet.

What are the SEO benefits of video content?

You need video content to boost search engine rankings. Videos feel more personal and let you share more value upfront, improving your website's click-through rate. Pages with videos:
\u2022 Have a higher chance of being selected as a feature snippet.
\u2022 Rank higher in Google image and Google video search results.
\u2022 Have longer dwell times as visitors spend longer on the page

There are hundreds of articles for every keyword you want to rank for - but only a handful of videos. Use the Instant video creator base plan to export five videos per month and start seeing the benefits of video marketing on your SEO.`,tags:["Partners","Agencies","Small Business","Content Creation","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/logo-8OFHBJOG2WN6B.png",developer:"vidon.ai"},{type:"app",name:"AI Social Content Generator",id:"ai-social-content-generator",url:"/apps/ai-social-content-generator/",description:`Do you want to create stunning videos with free captions and hashtags? 

Your wait is over. Say hello to the most complete social media content creation tool around!

Never be short of content ideas

Creator\u2019s block should not stop you from growing on social media. With just a few clicks of input, you'll get endless content ideas that can be converted into engaging social media posts. 

Creating trending videos was never this easy! 

Generate high-quality videos and interact directly with your audience. Creating Instagram reels and TikTok videos was never this easy! With a few simple clicks, you can create multiple videos using any of the hundreds and thousands of templates available on our platform. 

Add variety to your social media strategy

Generate videos, carousels, and posts all in the same place for Facebook, Instagram, TikTok, and much more! We\u2019ve got everything covered for you. Never miss the latest trends in text, images, or videos!

Establish your brand identity

Give a professional touch to your social media channels! Generate posts that speak your brand language. Using the color palettes of your brand, AI Social Content Generator gives all your posts a coherent and professional touch.

Deep dive into your competitors' data

Wondering how your competitors get conversions? The answer is just a click away!
Get AI-powered results that go deep into your competitors' behavior to deliver strategies that work`,tags:["Partners","Agencies","Most Popular","Content Creation","Social Media","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/predis-logo-square-KBZ349QDGDKNZ.png",developer:"Predis.ai"},{type:"app",name:"Consumer Surveys",id:"consumer-surveys",url:"/apps/consumer-surveys/",description:`Are you eager to gain valuable insights into consumer behavior? Look no further than MFour's
Consumer Surveys app. This revolutionary tool provides access to 12,500 monthly consumer
opinions, all tied to a staggering 550 million app, web, & location events. With this data, you can
understand not just what people say but also what they do in their daily lives.

With our app, you can:
\u2022 Learn venue, app, and web visitation reach and frequencies of consumers groups 
\u2022 See consumer habits and outlook on entertainment, health, home, shopping, and technology
\u2022 Use data to build segmented advertising strategies based on where consumers spend time online and off
\u2022 Request to field custom surveys related to your specific business topics

And more!`,tags:["Partners","Agencies","Ecommerce","Competitor Analysis"],iconUrl:"https://static.semrush.com/apps/static/MFour-Studio-badge-3-JQLCLL3ABLUEB.png",developer:"MFour Mobile Research"},{type:"app",name:"Keyword Analytics for YouTube",id:"keyword-analytics-for-youtube",url:"/apps/keyword-analytics-for-youtube/",description:`Want to boost your Youtube views or focus on trending topics for effective advertising?

It\u2019s almost impossible to see exactly what users are searching for directly on Youtube. That\u2019s why we created our Youtube keywords insights app. It provides keyword metrics so that your videos can reach more viewers. 

Uncover valuable insights in just a few clicks, including: 
\u2022 New keyword ideas
\u2022 The fastest-growing keywords
\u2022 Low-competition, high-value search terms
\u2022 The top videos for each keyword
\u2022 Commonly searched for phrases
\u2022 Other relevant trends

Users can also filter keywords by country and for daily, weekly, or monthly data.

Suitable for anyone who posts video content on YouTube, such as marketers, bloggers, vloggers, and agencies, gain valuable insights with the Keywords Ananlytics for Youtube app.`,tags:["Partners","Small Business","Social Media","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/Youtube_app_icon-589QAYKELAIDP.png",developer:"Iteora GmbH"},{type:"app",name:"Analytics Narratives",id:"analytics-narratives",url:"/apps/analytics-narratives/",description:`Want to get more out of your website data\u2014but don\u2019t have the time?

With Analytics Narratives, you can automatically import data from Google Analytics. Get automated narratives with intelligent insights that boost your marketing efforts.

Receive automated reports direct to your inbox:
-Spend less time switching back and forth between multiple tools and dashboards. Simply connect your Google Analytics account and let Analytics Narratives do the heavy lifting.
- Running several campaigns at once? Connect multiple Google Analytics sources and generate reports for various websites.
- Schedule reports on a daily, weekly, or monthly basis.

Stay notified of any changes:
- Don\u2019t be caught off guard. Receive alerts anytime there is an anomaly in your website data, and stay aware of any unexpected user behavior changes or data spikes.

Make more sense of your data:
- Receive personalized insights that help you understand your users
- Make intelligent data-driven decisions
- Improve your daily marketing activities.`,tags:["Partners","Agencies","Small Business","Analytics & Reports"],iconUrl:"https://static.semrush.com/apps/static/Analytics-Narratives-App-Icon-A7L952WGULJQZ.png",developer:"Narrative BI"},{type:"app",name:"AI Writing Assistant",id:"ai-writing-assistant",url:"/apps/ai-writing-assistant/",description:`Are you creating enough content for your marketing efforts to be successful? 

You might have a stellar strategy, but creating all the top-tier content you need can be a big challenge. Relieve the burden on your creative team and free them to achieve even more with AI Writing Assistant. 

Hit all your deadlines.
\u2022 Write original articles in 25+ languages
\u2022 Structure articles with headers and lists
\u2022 Target keywords for optimal SEO performance

Empower your team to create better content.
\u2022 Draft articles in a click so writers can spend more time perfecting
\u2022 Detect plagiarism 
\u2022 Brainstorm more effectively with lots of new ideas
\u2022 Find new keywords to target

Create all the content types you need in a click.
\u2022 Optimized web copy
\u2022 Blog posts and articles
\u2022 Social media posts
\u2022 Paid ads
\u2022 Emails
\u2022 Product descriptions

Never worry about writer\u2019s block or deadlines again. Leverage AI to create content that outperforms your competitors, no matter the industry.`,tags:["Partners","Agencies","Content Creation","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/copymatic-semrush--logo--c2x%20(1)-FBHSYB14OTK7T.png",developer:"Copymatic"},{type:"app",name:"Headline Optimizer",id:"headline-optimizer",url:"/apps/headline-optimizer/",description:`You might think you have quality Google ad copy, but does your audience think the same?

Unfortunately, there is no way of knowing if your customers like your ads until after your campaign runs. Live A/B testing also takes a long time to give meaningful results. All you end up with is a wasted ad budget and no new customers to show for it. 

But don't worry - you finally have a solution. The Headline Optimizer app gives you Google ad headline suggestions which you can A/B test with a panel of 500,000+ real human testers. Our testers are paid and based in the USA. They are highly motivated to share their honest and unbiased opinions. Get valuable early feedback before your ad launch! 

1) Run your ads with "Ad Strength - Excellent" headlines
Do you have the "Ad Strength" and headlines for optimal Google ad performance? You can find out now by polling our panel of active human testers. You can:
\u2022 Explore ad headlines for your keyphrase and run A/B tests with a panel of human testers. 
\u2022 Choose statistically significant better headlines and incorporate user feedback. 
\u2022 No more wasting money on guesswork and failed campaigns!

2) Get "Asset Performance - Best" in your asset performance report
If your Google ad asset performance report shows "low performance," you know there is room for improvement. But what about "good performance" reports? Did you know that just "good" is not good enough with Google ads? If you really want to save money and still reach the maximum possible customers, you need "Asset Performance - Best." And Headline Optimizer helps you achieve that!

\u2022 Find automated recommendations to go with your ad copy.
\u2022 Discover optimum ad headlines to add to your responsive search ads. 
\u2022 Compare unlimited headlines for a fixed monthly price

3) Solve the "forever testing" problem with your PPC campaigns
High PPC ads are tough to optimize using live campaigns since tests take forever. Google may take months to finish "learning", and keep charging you while it does so. Do you really have the budget for extended A/B testing without any returns? Instead, you can use Headline Optimizer to:

4) Quickly A/B test your ad strength and assets - without burning the budget. 
\u2022 A/B test the best headlines to pin to the top positions. 
\u2022 Run unlimited A/B tests at a fixed monthly cost`,tags:["Partners","Agencies","Small Business","Content Creation","Advertising","AI Apps"],iconUrl:"https://static.semrush.com/apps/static/Headline-Optimizer%20Icon-O7L0ZX96SJD3.png",developer:"Poll the People"},{type:"app",name:"TrendFeed",id:"trendfeed",url:"/apps/trendfeed/",description:`Looking to be the first to secure early market insights? 

You could have world-class content, but if your competitors are telling the most compelling narratives first\u2014before you even have a chance to launch your content\u2014you\u2019ll have trouble securing your audience's attention. 

But with TrendFeed, you can wipe that particular worry right off your plate. This app gives you trend and marketing intelligence that will make you the first to know what is happening in your market or sector. 

Get alerted to emerging trends 
\u2022 Research hundreds of topics across dozens of industries to get a 360-view of where your market is headed 
\u2022 Use the trend level alerts to determine which stories are getting the most viral traction
\u2022 Save topic feeds and emerging stories for your own records 

Find your own trends, or search the library 
\u2022 Browse the TrendFeed library to get hundreds of pre-selected content feeds, including everything from healthcare to retail and technology 
\u2022 Use one or two of your own keywords to find topics with specific relevance to your needs 
\u2022 Share topic feeds and stories with colleagues and other stakeholders so everyone remains informed

Create content that blows past the competition and gives your followers exactly what they want
\u2022 TrendFeed updates hourly so you get the freshest content ideas on the market 
\u2022 Use the hundreds of topics available to form whole strategies, down to individual pieces of content 
\u2022 Signal to Google and your readers that you are an authoritative source of news and information
\u2022 Create compelling narratives instantly, in multiple languages and increase your SEO`,tags:["Partners","Agencies","Media Monitoring","Content Creation"],iconUrl:"https://static.semrush.com/apps/static/Trandfeed-IS5PI214V3SRE.png",developer:"TrendSpottr"},{type:"app",name:"Shopify Finder",id:"shopify-finder",url:"/apps/shopify-finder/",description:`With access to insights on over 50 million Shopify and 100 million AliExpress products, Shopify Finder is one of the most comprehensive dropshipping niche product research apps. Armed with this intel, any e-commerce seller can quickly run product research and find the next winning product. 

Tinker with this app to discover products that have both the demand and the profits:

- Stop choosing the wrong products and losing money: with all-encompassing product data (from price to order and sales trends), you can estimate whether a product is likely to bring in profits.
- Find out how many stores are also selling your chosen product and unwrap your competitors' sales specs: pricing, orders, shelf life, etc.

Shopify Finder has 20+ filters that help you navigate through product specs from both Shopify and AliExpress.

The app has product coverage for over 40 countries, updating its product database on an hourly basis.

Start placing your bets on the right products and turn your Shopify store into a profitable business!`,tags:["Partners","Ecommerce","Small Business","Competitor Analysis"],iconUrl:"https://static.semrush.com/app-center/apps_images/shopify-finder/logo.png",developer:"FindNiche"},{type:"app",name:"Audience Intelligence",id:"audience-intelligence",url:"/apps/audience-intelligence/",description:`Understanding your audience is key to your success. But how do you keep up when people\u2019s habits, needs, and preferences keep evolving?

The Audience Intelligence app allows you to identify and truly understand your audience. Its intel comes from both traditional analytics and data from social networks, which makes this app unlike any other keyword-based or traditional consumer research-based solution. 

All you have to do to get an all-encompassing audience analysis is to type in the @handle of the account you want to explore!

Get a real picture of your target audience\u2014identify and gain insights into your audience by looking at their demographics, interests, content engagement, online habits, and purchasing behavior.

Market to individuals and not the masses\u2014the app\u2019s unique social consumer segmentation provides a strong data foundation for persona development, pinpointing relevant audiences, and finding new customer segments. 

Discover interest and affinities\u2014the app\u2019s Affinity segmentation method delivers actionable insights and more targeted audience intel, helping to identify niche segments with common interests inferred from similar sets of accounts they follow. 

Identify potential influencers and top communication platforms\u2014find creators that your audience listens to and trusts, and confirm they are the right fit for your brand. Plus, you\u2019ll get to uncover the most relevant online/offline channels, media outlets, and social networks to reach your audience.

Personalize your strategy\u2014with stronger segmentation, you can better personalize your offerings and messaging, and gain cultural relevance to improve your engagement and strategy\u2014be it about influencer/sponsorship selection, content/creative development, PR and comms, and media planning.`,tags:["Partners","Agencies","Most Popular","Competitor Analysis","Social Media","Advertising"],iconUrl:"https://static.semrush.com/app-center/apps_images/audience-intelligence/logo.png",developer:"Audiense"},{type:"app",name:"FindThatLead Domain Searcher",id:"findthatlead-domain-searcher",url:"/apps/findthatlead-domain-searcher/",description:`Email is still the best way to reach out to someone and build a 1:1 relationship. Take advantage of it and use the FindThatLead Domain Searcher app to extract the emails of an entire company or domain just by indicating the company name or its URL. It couldn't get any easier!

Find the contact of the person you are looking for in just a few seconds:

FindThatLead Domain Searcher is an app that will help you find the email address of the person you are looking to reach. The contact found will come with a name, email, and corresponding role in their company. Do you need to find a potential customer's contact info to show them your product? Do you want to propose a collaboration? Are you looking for a quality backlink? If your answer is YES\u2014you've found the right tool!

Discover key information about the companies you are seeking:

This app does not only display lead information, it gathers public data about the company you are searching for and features relevant information about it:
- Logo
- Social Media
- Phone Numbers
- Location
- Related domains
- Backlinks (the app shows a list of quality backlinks that are currently generating traffic to the domain you are exploring)

Verify all emails in just one click:

Worried that the email you found is not correct? Now you can instantly verify the veracity of the emails you see directly from the tool; just a click is enough! The tool will show you a score-based ranking of the verification to help you reduce bounces.

Extract and export all your results:

The app lets you download the list of a company's leads\u2014so it's up to you to make the most of the results. Will you send them an email? Add them to a mass cold email campaign? Include them in an audience? Feel free to do it all!

Here's a rough idea of what kinds of profiles you can gather through the app:

- A wide range of salespeople
- Marketing and SEO specialists
- Human Resources professionals
- Content creators looking for new collaborations
- All kinds of B2B freelancers (designers, developers, consultants...)
- Digital agencies

Try FindThatLead Domain Searcher and transform your outbound lead generation strategy now!`,tags:["Partners","Agencies","Small Business"],iconUrl:"https://static.semrush.com/apps/static/findthatlead_icon-ECOF6YUP8SH3Z.png",developer:"FindThatLead"},{type:"app",name:"Media Monitoring",id:"media-monitoring",url:"/apps/media-monitoring/",description:`Media Monitoring is more than just an app for tracking your brand mentions. Because brand monitoring doesn't just stop there - it provides a way to turn unlinked brand mentions into valuable backlinks.

It becomes increasingly important to keep track of what people are saying about your brand online. Tinker with the app and turn your mentions into valuable assets for your brand:

- Get customer insights and feedback: collect customer feedback across dozens of platforms

- Protect your online reputation: use sentiment analysis to respond to negative comments and turn haters into fans

- Analyze competitors: use the app to track mentions about your competitors to get the complete picture

- Invest in backlinks that matter: prioritize the mentions and connect with authors for backlinks 

- Find influencers: discover people who are talking about your brand and have the right reach\u2014and turn them into your brand ambassadors

Make the most of your brand mentions with Media Monitoring.`,tags:["Partners","Small Business","Most Popular","Media Monitoring"],iconUrl:"https://static.semrush.com/app-center/apps_images/media-monitoring/logo.png",developer:"Brand24"},{type:"app",name:"Website Testing",id:"website-testing",url:"/apps/website-testing/",description:`Getting people to visit your site can sometimes feel like Mission: Impossible.

But your job doesn\u2019t even stop there. Technical matters can break the deal and make your visitors bounce, even if you have the most resonant content and the most appealing site design.

The Website Testing app is a great spy tool for site functionality. All you need is a mouse and a keyboard to set up the app, and it will instantly point to any potential deal-breakers.

Make sure your website looks and functions perfectly across any browser, operating system, or device
\u2022 Test your site on the most popular browsers (Chrome, Mozilla Firefox, Microsoft Edge, Safari, and Opera).
\u2022 Access the latest browser versions along with a large number of older ones.
\u2022 Run mobile web testing with Android emulators (Android 4.4 - 11), iOS simulators (iOS 12 - 15), or physical mobile devices.

Ensure the ultimate UX and UI by ensuring your features don\u2019t suddenly fall off
\u2022 Interactively test your site with a remote browser, or generate screenshots in multiple browsers (1000+ browser combinations).
\u2022 Check your site's appearance on various screens and run responsive testing by changing the screen resolution.
\u2022 Secure accurate locale optimization by exploring your site across multiple geolocations (Europe, Americas, and Asia).
\u2022 Test your website for accessibility issues with the integrated NVDA and VoiceOver feature

Fix any site issues before visitors see them\u2014make sure to take screenshots whenever you spot any design or compatibility issues and email them straight to your colleagues.`,tags:["Partners","Agencies","Small Business","Web Design"],iconUrl:"https://static.semrush.com/app-center/apps_images/website-testing/website-testing-icon.png",developer:"TestingBot"},{type:"app",name:"Video Submission Management",id:"video-submission-management",url:"/apps/video-collector/",description:`The secret to video testimonials is to make it easy for customers to upload their own feedback videos. Video Submission Management does just that!

Video Submission Management is an all-in-one video testimonial app that makes it easy for your users to share their praise so you can build trust with prospects and increase sales. 

This app has everything you need to entice your customers to actually take the time and share their thoughts in a video format. All you have to do is share a magic link!

With Video Submission Management, you can:

- Create a landing page with a short brief and customer questions. And\u2026brand it! This leaves little room for hesitation from customers almost ready to share their feedback.

- Set up standardized formatting \u2014 to receive visually-consistent videos that look just the way you want them to look and to actually be able to use them across platforms.

- Get a magic link that you can share with anyone, anywhere, at any time.

- Build a library of user-generated videos with the tool taking care of all the re-use permission requests - so you can use those video testimonials across any marketing channel!

Try Video Submission Management and easily collect testimonials videos from anyone, anywhere!`,tags:["Partners","Agencies","Ecommerce","Small Business","Content Creation"],iconUrl:"https://static.semrush.com/app-center/apps_images/video-collector/video-collector-icon.png",developer:"Vloggi"},{type:"app",name:"Lead Generation Forms",id:"lead-generation-forms",url:"/apps/lead-generation-forms/",description:`Lead Generation Forms is an online form builder that helps you engage your site\u2019s visitors and gain valuable contacts - all at the same time. 
 
This easy-to-use lead generation form builder features:
 
- An intuitive drag-and-drop interface that helps to create forms in minutes. 
- Page breaks with logical jumps to assist your creativity.
- Formula and Calculation fields to create all kinds of calculations. 
- Personality and fun quiz templates with lead generation fields. 
- Ready-to-embed code for adding forms and quizzes to your site. Supports custom domains!   
- A Response Inbox space that stores all the answers. 
 
Leverage the full power of Lead Generation Forms:
 
- Stand out from the competition by adding lead-generating forms and quizzes to your website.
- Turn web calculators into a lead generation machine by adding contact fields and special offers. 
- Run customer development and customer satisfaction surveys with video questions and collect audio and video responses.`,tags:["Partners","Agencies","Small Business","Content Creation"],iconUrl:"https://static.semrush.com/app-center/apps_images/interactive-form-builder/Interactive_form_builder_app_logo.png",developer:"AidaForm"},{type:"app",name:"Ecommerce Keywords Analytics",id:"ecommerce-keywords-analytics",url:"/apps/ecommerce-keywords-analytics/",description:`Ever wanted to take a sneak peek at the biggest ecommerce players\u2019 top-performing keywords to amplify your strategies? With the Ecommerce Keywords Analytics app, you can do this in no time.

Ecommerce Keyword Analytics allows you to pinpoint which keywords bring the highest impact to major e-tailers and to understand shoppers' demand patterns\u2014all to build smarter marketing campaigns across marketplaces.

Learn from the top retailers\u2019 keyword strategies\u2014the app provides in-depth analysis for search keywords across major online retailers in 16 countries. Amazon, Walmart, eBay, Best Buy, Etsy, ASOS, MediaMarkt, Zalando, and many others\u2014you\u2019ll get to analyze them all.

Evaluate any keyword\u2019s performance\u2014reveal any ecommerce keyword\u2019s most important stats\u2014search volume, clicks, and orders\u2014to prioritize your own optimization efforts. 

Assess ecommerce keywords\u2019 conversion potential\u2014discover new opportunities with unique ecommerce keyword data\u2014number of product page visits, number of "Add to basket events," and conversions.

Explore demand trends\u2014you can also analyze any keyword by domain, country, or month to pinpoint demand trends: seasonality, locales that have the highest interest in that keyword, and competitors who target them.

Use keyword intel to level up your product strategy\u2014pinpoint which products relate to the best ecommerce keywords to: a) unwrap similar keywords (aka products) to tackle the most efficient search terms; b) reveal consumer interest trends that can impact your demand.`,tags:["Partners","Ecommerce","Small Business","Most Popular","Competitor Analysis","Keyword Research"],iconUrl:"https://static.semrush.com/app-center/apps_images/e-commerce-keywords-analytics/E-commerce_Keyword_Analytics_app_logo.png",developer:"Iteora GmbH"},{type:"app",name:"Accessibility Scan & Monitor",id:"accessibility-scan---monitor",url:"/apps/accessibility-scan-and-monitor/",description:`Do you have a web accessibility plan for your site? 

Make sure your site is useable for everyone with the Accessibility Scan & Monitor app. It can: 
\u2022 Automatically check that your website aligns with WCAG (Web Content Accessibility Guidelines) 
\u2022 Verify that your site complies with legal requirements like ADA (Americans with Disabilities Act)
\u2022 Help you improve accessibility for people with disabilities
\u2022 Open your online sales channel to over one billion people with disabilities, who might not have had access to your products or services otherwise

Regularly checking the accessibility of your site isn\u2019t just the right thing to do. It can also boost your online sales potential, and even help you stay WCAG and ADA compliant. 

Perform comprehensive accessibility checks on desktop and mobile
\u2022 Scan for issues that may only appear on specific screen sizes and devices 
\u2022 Conduct up to 30,000 scans on mobile and desktop sites with over 15,000 pages in under an hour
\u2022 Deliver large-scan first results in mere minutes

Prioritize your biggest accessibility issues:
\u2022 Focus on site-wide and template-level violations affecting most of your site\u2019s pages. 
\u2022 Get the most out of your team's efforts and ROI for your organization.
\u2022 Improve compliance with the WCAG, ADA, Section 508, EN 301-549, and the AODA`,tags:["Partners","Agencies","Web Design"],iconUrl:"https://static.semrush.com/apps/static/semrush-logo-BMHTTZT8I0HER(1)-9BM1II0QRJZD3.png",developer:"UserWay"},{type:"app",name:"AdClarity \u2013 Advertising Intelligence",id:"adclarity---advertising-intelligence",url:"/apps/adclarity-advertising-intelligence/",description:`Do you have what it takes to build an unbeatable advertising strategy?

You might have the most appealing ad copy, the best visuals, and an incredible traffic manager, but if you don\u2019t know what your competitors are doing, your advertising efforts can come to naught.

Not to worry\u2014the AdClarity \u2013 Advertising Intelligence app has your back. This app delivers all-around insights on your rivals\u2019 display, social, and video advertising campaigns and their performance. 

Get an in-depth view of your competitors\u2019 advertising strategies
\u2022 Explore your rivals\u2019 digital advertising campaigns and reveal their total advertising spend and share of voice
\u2022 Assess their campaigns\u2019 key performance stats\u2014impressions, costs, views, clicks, and more

Learn from your rivals\u2019 hits and misses 
\u2022 Reveal competitors\u2019 most popular messaging and visuals\u2014and see what kind of engagement they produce
\u2022 Find your competitors\u2019 most valuable publishers and traffic sources by seeing the impact they bring
\u2022 Pinpoint any campaign seasonality by reviewing launch date trends

Use these insights to fine tune your own advertising strategy
\u2022 Find out how much your competitors are investing across channels to achieve their results 
\u2022 See outcomes from various publishers and make a note for your own ad placements
\u2022 Unveil your rivals\u2019 most-advertised products and offerings, as well as the way they promote them
\u2022 Create advertising campaigns that are set for maximum audience reach and performance`,tags:["Partners","Agencies","Small Business","Most Popular","Competitor Analysis","Advertising"],iconUrl:"https://static.semrush.com/app-center/apps_images/adclarity-advertising-intelligence/adclarity-icon-new.png",developer:"Biscience Ltd"},{type:"app",name:"Instant Banner Generator",id:"instant-banner-generator",url:"/apps/instant-banner-generator/",description:`Does keeping up with the constant flow of fresh content and visuals needed for effective social media and display advertising feel like driving a race car? 

So you\u2019d think you have to hire a professional racer designer or someone with the technical acumen to keep creating compelling designs.

With Instant Banner Generator, you no longer have to turn to external help\u2014the app takes care of all your visuals while you can focus on the strategic part of your work.

Create thousands of social media and display banners in seconds

\u2022 Automate your banner creation process by letting the app build high-converting, professional-quality banners 
\u2022 Benefit from the app\u2019s auto-design features that keep your visuals within your brand guidelines 
\u2022 Don\u2019t spend time finding the perfect designer or learning new design skills

Enjoy having banners that always come in the right size and format

\u2022 The app supports the most popular social media banner formats: Facebook Feed, Facebook Square, Tweet Post, Promoted Tweet, and LinkedIn Feed
\u2022 It also has pre-set IAB display formats so you never have to go back and forth finding relevant specs for your designs

Save your designs for future use or further edits

\u2022 Easily go back and forth to edit the content of your generated banners. You can even change their format without having to do anything but a single click
\u2022 Keep your favorite designs or banner content\u2014and use them in your future marketing activities

Ever thought you\u2019d find a way to easily generate new banners? With Instant Banner Generator, it\u2019s as easy as one, two, three (and four): 
1. Choose your banner formats 
2. Add your content 
3. Get auto-designed banners 
4. Download and enjoy!`,tags:["Partners","Agencies","Small Business","Content Creation","Social Media","Advertising","AI Apps","Web Design"],iconUrl:"https://static.semrush.com/app-center/apps_images/instant-banner-generator/Instant_Banner_Generator_app_logo.png",developer:"Abyssale"},{type:"app",name:"Rank Tracker for YouTube",id:"rank-tracker-for-youtube",url:"/apps/rank-tracker-for-youtube/",description:`Want to embrace everything the world\u2019s second-largest search engine has to offer? Right, the ever-expanding rise of video and around 2 billion active users make YouTube more than attractive for any marketer. But how do you find your success within the it-place?

Just as with any creative endeavor, your YouTube success is never just about the artistic specs. You have to consider YouTube algos, competing videos, and SEO elements that are all part of the package.

The Rank Tracker for YouTube app takes care of the dreary yet crucial part of the non-creative process\u2014tracking your YouTube rankings to enhance your videos' performance. 

Match your YouTube rankings with the keywords that matter to your business

\u2022 The app automatically tracks your weekly rank changes
\u2022 You have full freedom to choose the keyword-video pairings you want to monitor 

Easily spot your YouTube SEO wins and losses

\u2022 With constant tracking, you can avoid significant position drops\u2014and take timely action when needed
\u2022 Thanks to instant reaction, you can win back your keyword rankings and make sure your videos are actually visible to your target audience

Find new growth points for your or your clients\u2019 YouTube channels

\u2022 The app allows you to add as many YouTube channels as you need\u2014so you can easily manage multiple video marketing campaigns for various accounts at the same time through a completely user-friendly interface
\u2022 By having an on-spot overview of your videos\u2019 performance stats\u2014top keywords, average position, keyword distribution, and rank changes\u2014you can instantly notice some laggers or winners with the biggest potential, and allocate your YouTube SEO efforts accordingly`,tags:["Partners","Small Business","Social Media","Keyword Research"],iconUrl:"https://static.semrush.com/apps/static/Picto-Purple-with-some-margin-1Q76DT3PYYWH5.png",developer:"Tubics"},{type:"app",name:"Mobile App Insights",id:"mobile-app-insights",url:"/apps/mobile-app-insights/",description:`You know how some apps seem to be everywhere? They show up in the Top Charts, pop up in ads, and win all the category rankings.

That can be your app, too. Mobile App Insights has all the essentials to maximize your mobile app's visibility and even conversions.

Level Up Your Rankings By Showing Up For the Most Valuable Keywords
\u2022 With access to the app\u2019s extensive keyword resources, you can discover impactful and valuable keywords for your mobile app
\u2022 Monitor the keyword ranking history for all of your tracked keywords\u2014and take timely action if you see position drops

Reveal Competing Apps\u2019 Success Strategies  
\u2022 Get all the necessary intel to decode the marketing and product activities of any mobile app
\u2022 Discover your app\u2019s and your competitors\u2019 visibility scores to understand your stance within the market
\u2022 See which keywords produce the biggest results for your rivals\u2014be it about impressions or conversions

Become a Top Charts Champ
\u2022 Spot category ranking changes of any app
\u2022 Compare your category ranking to that of your competitors\u2014and see the ranking trend in a single convenient chart
\u2022 Analyze your app\u2019s category ranking changes in different storefronts for the dates you choose

Finetune Your Apple Search Ads Strategy
\u2022 Discover paid keywords for every app along with their impression shares
\u2022 Reveal keywords that trigger downloads\u2014and use them across your own campaigns 
\u2022 See who\u2019s running ads for a given keyword and assess its competitive potential`,tags:["Partners","Agencies","Most Popular","Competitor Analysis","Keyword Research"],iconUrl:"https://static.semrush.com/app-center/apps_images/mobile-app-insights/Mobile_App_Insights_app_logo.png",developer:"Mobile Action"}],Fo=[{type:"extra-tool",id:"content-marketplace",name:"Content Marketplace",url:"https://www.semrush.com/marketplace/",description:"[Generated] Get quality content written by professional copywriters",tags:["Content marketing"]},{type:"extra-tool",id:"content-outline-builder",name:"Content Outline Builder",url:"https://www.semrush.com/outline-builder/",status:"beta",description:"[Generated] Create a content brief for your copywriters and editors",tags:["Content marketing"]},{type:"extra-tool",id:"impacthero",name:"ImpactHero",url:"https://www.semrush.com/impacthero/",description:"[Generated] Create a content brief for your copywriters and editors"},{type:"extra-tool",id:"tools-for-amazon",name:"Tools for Amazon",url:"https://lp.sellzone.com/amazon-marketing-tools.html?utm_source=semrush&utm_medium=extratools",description:"[Generated] Optimize your Amazon listings and ads"},{type:"extra-tool",id:"prowly",name:"Prowly",url:"https://prowly.com/?utm_source=semrush&utm_medium=extratools",description:"[Generated] Manage your PR campaigns and build relationships with journalists",tags:["Social media"]},{type:"extra-tool",id:"kompyte",name:"Kompyte",url:"https://www.kompyte.com/?utm_source=semrush&utm_medium=extratools",description:"[Generated] Track your competitors' marketing strategies",tags:["Competitive research"]},{type:"extra-tool",id:"splitsignal",name:"SplitSignal",url:"https://www.semrush.com/splitsignal/",status:"beta",description:"[Generated] Test your website's design and content"},{type:"extra-tool",id:"custom-reports",name:"Custom reports",url:"https://www.semrush.com/company/custom_report/",description:"[Generated] Create custom reports for your clients"},{type:"extra-tool",id:"surround-sound",name:"Surround Sound",url:"https://www.semrush.com/srm/",description:"Uncover the domains and pages that rank for your keywords, the ones that mention your competition, and those that are mentioning you. Get valuable links and mentions to grow your share of search, whether you rank or not.",tags:["SEO","Competitive research"]},{type:"extra-tool",id:"pageimprove",name:"PageImprove",url:"https://www.semrush.com/pageimprove/",description:"[Generated] Get a prioritized list of issues that are affecting your page's performance in search engines. Fix them to improve your rankings and traffic."}],Go=[{type:"tool",id:"seo-dashboard",name:"SEO Dashboard",url:"https://www.semrush.com/seo/",projectUrl:"https://www.semrush.com/seo/:projectId",description:"Get a complete overview of your projects SEO performance.",tags:["SEO"]},{type:"tool",id:"domain-overview",name:"Domain Overview",url:"https://www.semrush.com/analytics/overview/",description:"Get instant insights into strengths and weaknesses of your competitor or prospective customer.",tags:["SEO","Competitve research","Advertising","Market analysis"]},{type:"tool",id:"traffic-analytics",name:"Traffic Analytics",url:"https://www.semrush.com/analytics/traffic/overview/",description:"Explore competitors\u2019 website traffic stats, discover growth points, and amplify your marketing strategy.",tags:["SEO","Competitve research",".Trends"]},{type:"tool",id:"organic-research",name:"Organic Research",url:"https://www.semrush.com/analytics/organic/overview/",description:`Do you want to reach the top of the SERP?
Start with learning what works best for your competitors.`,tags:["SEO","Competitve research"]},{type:"tool",id:"keyword-gap",name:"Keyword Gap",url:"https://www.semrush.com/analytics/keywordgap/",description:"A tool that helps you compare your keyword profile with your competitors.",tags:["SEO","Competitve research","Advertising"]},{type:"tool",id:"backlink-gap",name:"Backlink Gap",url:"https://www.semrush.com/analytics/gap/backlinks/",description:"A tool that helps you compare your backlink profile with your competitors.",tags:["SEO","Competitve research","Advertising"]},{type:"tool",id:"keyword-overview",name:"Keyword Overview",url:"https://www.semrush.com/analytics/keywordoverview/",description:"Dive into the largest keyword research database on the market and analyze everything you need to know about a keyword.",tags:["SEO","Keyword research"]},{type:"tool",id:"keyword-magic-tool",name:"Keyword Magic Tool",url:"https://www.semrush.com/analytics/keywordmagic/",description:"Find millions of keyword suggestions for your SEO. ",tags:["SEO","Keyword research","Advertising"]},{type:"tool",id:"keyword-manager",name:"Keyword Manager",url:"https://www.semrush.com/analytics/keywordmanager/",description:"[Generated] Manage your keyword lists and track your rankings with the Keyword Manager.",tags:["SEO","Keyword research"]},{type:"tool",id:"position-tracking",name:"Position Tracking",url:"https://www.semrush.com/position-tracking/",description:"[Generated] Track your website\u2019s daily rankings for any keyword in any location and get a complete picture of your website\u2019s ranking performance.",tags:["SEO","Keyword research","Local SEO","Advertising","Ad tracking"]},{type:"tool",id:"organic-traffic-insights",name:"Organic Traffic Insights",url:"https://www.semrush.com/organic_traffic_insights/",description:"[Generated] Get instant insights into the most effective SEO and content strategies used by your competitors.",tags:["SEO","Keyword research"]},{type:"tool",id:"backlink-analytics",name:"Backlink Analytics",url:"https://www.semrush.com/analytics/backlinks/overview/",description:"[Generated] Get a deep dive into your backlink profile and understand how your backlinks impact your SEO performance.",tags:["SEO","Link building"]},{type:"tool",id:"backlink-audit",name:"Backlink Audit",url:"https://www.semrush.com/backlink_audit/",description:"[Generated] Find and remove toxic backlinks to your site with the Backlink Audit tool.",tags:["SEO","Link building"]},{type:"tool",id:"link-building-tool",name:"Link Building Tool",url:"https://www.semrush.com/link_building/",description:"[Generated] Find link-building opportunities, track link-building progress, and analyze incoming links to your site with the Link Building Tool.",tags:["SEO","Link building"]},{type:"tool",id:"bulk-analysis",name:"Bulk Analysis",url:"https://www.semrush.com/batch/",description:"[Generated] Analyze your competitors, find link building opportunities, and export results to XLSX or CSV.",tags:["SEO","Link building"]},{type:"tool",id:"site-audit",name:"Site Audit",url:"https://www.semrush.com/siteaudit/",description:"[Generated] Find and fix technical issues on your website with the Site Audit tool.",tags:["SEO","Technical SEO","Local SEO"]},{type:"tool",id:"listing-management",name:"Listing Management",url:"https://www.semrush.com/listings-management/",description:"[Generated] Manage your business listings and reputation across multiple platforms.",tags:["SEO","Technical SEO","Local SEO"]},{type:"tool",id:"seo-content-template",name:"SEO Content Template",url:"https://www.semrush.com/seo-content-template/",description:"[Generated] Create SEO-friendly content based on comprehensive research and competitors\u2019 analysis.",tags:["SEO","Technical SEO","Content marketing"]},{type:"tool",id:"on-page-seo-checker",name:"On Page SEO Checker",url:"https://www.semrush.com/on-page-seo-checker/",description:"[Generated] Get actionable recommendations based on collected data to improve your website\u2019s SEO performance.",tags:["SEO","Technical SEO","Local SEO"]},{type:"tool",id:"log-file-analyzer",name:"Log File Analyzer",url:"https://www.semrush.com/log-file-analyzer/",description:"[Generated] Analyze your log files and get valuable insights into search engine crawling behavior on your website.",tags:["SEO","Technical SEO"]},{type:"tool",id:"review-management",name:"Review Management",url:"https://www.semrush.com/review-management/",description:"[Generated] Manage your online reputation and collect reviews to build trust and increase conversions.",tags:["Local SEO"]},{type:"tool",id:"advertising-dashboard",name:"Advertising Dashboard",url:"https://www.semrush.com/ppc/",description:"[Generated] Get a complete overview of your PPC performance in one place.",tags:["Advertising"]},{type:"tool",id:"advertising-research",name:"Advertising Research",url:"https://www.semrush.com/analytics/adwords/positions/",description:"[Generated] Analyze your competitors\u2019 Google Ads campaigns and get insights into your competitors\u2019 PPC strategies.",tags:["Advertising","Market analysis"]},{type:"tool",id:"display-advertising",name:"Display Advertising",url:"https://www.semrush.com/analytics/da/",description:"[Generated] Analyze your competitors\u2019 display ads and get insights into your competitors\u2019 display advertising strategies.",tags:["Advertising","Market analysis"]},{type:"tool",id:"pla-research",name:"PLA Research",url:"https://www.semrush.com/analytics/pla/positions/",description:"[Generated] Analyze your competitors\u2019 Google Shopping campaigns and get insights into your competitors\u2019 PLA strategies.",tags:["Advertising","Market analysis"]},{type:"tool",id:"ppc-keyword-tool",name:"PPC Keyword Tool",url:"https://www.semrush.com/keyword-tool/",description:"[Generated] Find the right keywords for your Google Ads campaigns with the PPC Keyword Tool.",tags:["Advertising","Keyword research"]},{type:"tool",id:"ads-history",name:"Ads History",url:"https://www.semrush.com/analytics/phrase/",description:"[Generated] Analyze your competitors\u2019 Google Ads campaigns and get insights into your competitors\u2019 PPC strategies.",tags:["Advertising","Keyword research"]},{type:"tool",id:"social-dashboard",name:"Social Dashboard",url:"https://www.semrush.com/social-media/",description:"[Generated] Get a complete overview of your social media performance in one place.",tags:["Social media"]},{type:"tool",id:"social-poster",name:"Social Poster",url:"https://www.semrush.com/social-media/?tool=poster",description:"[Generated] Schedule and post content to your social media accounts.",tags:["Social media"]},{type:"tool",id:"social-tracker",name:"Social Tracker",url:"https://www.semrush.com/social-media/?tool=tracker",description:"[Generated] Track your social media performance and compare it to your competitors\u2019 performance.",tags:["Social media"]},{type:"tool",id:"social-analytics",name:"Social Analytics",url:"https://www.semrush.com/social-media/?tool=analytics",description:"[Generated] Analyze your social media performance and compare it to your competitors\u2019 performance.",tags:["Social media"]},{type:"tool",id:"social-inbox",name:"Social Inbox",url:"https://www.semrush.com/social-media/?tool=inbox",status:"beta",description:"[Generated] Manage all your social media messages in one place.",tags:["Social media"]},{type:"tool",id:"get-started",name:"Get Started",url:"https://www.semrush.com/content-marketing/get-started/",description:"[Generated] Get started with Content Marketing Toolkit.",tags:["Content marketing"]},{type:"tool",id:"topic-research",name:"Topic Research",url:"https://www.semrush.com/topic-research/",description:"[Generated] Find the most popular content around the topic of your choice.",tags:["Content marketing"]},{type:"tool",id:"seo-writing-assistant",name:"SEO Writing Assistant",url:"https://www.semrush.com/swa/",description:"[Generated] Write SEO-friendly content with the SEO Writing Assistant.",tags:["Content marketing"]},{type:"tool",id:"brand-monitoring",name:"Brand Monitoring",url:"https://www.semrush.com/mentions/",description:"[Generated] Monitor your brand\u2019s online presence and get insights into your competitors\u2019 strategies.",tags:["Content marketing"]},{type:"tool",id:"contentshake",name:"ContentShake",url:"https://www.semrush.com/app/contentshake/",status:"new",description:"[Generated] Get content ideas for your blog and create high-quality content with ContentShake.",tags:["Content marketing"]},{type:"tool",id:"post-tracking",name:"Post Tracking",url:"https://www.semrush.com/post-tracking/",description:"[Generated] Track the performance of your articles and get insights into your competitors\u2019 strategies.",tags:["Content marketing"]},{type:"tool",id:"content-audit",name:"Content Audit",url:"https://www.semrush.com/content-audit/",description:"[Generated] Audit your content and get insights into your competitors\u2019 strategies.",tags:["Content marketing"]},{type:"tool",id:"market-explorer",name:"Market Explorer",url:"https://www.semrush.com/market-explorer/overview/",description:"[Generated] Analyze your market and get insights into your competitors\u2019 strategies.",tags:[".Trends"]},{type:"tool",id:"eyeon",name:"EyeOn",url:"https://www.semrush.com/eyeon-monitoring/",description:"[Generated] Monitor your competitors\u2019 online activities and get insights into their strategies.",tags:[".Trends"]},{type:"tool",id:"one2target",name:"One2Target",url:"https://www.semrush.com/analytics/one2target/demographics/",description:"[Generated] Analyze your target audience and get insights into your competitors\u2019 strategies.",tags:[".Trends"]},{type:"tool",id:"agency-partners",name:"Agency Partners",url:"https://www.semrush.com/agencies/landing/",description:"[Generated] Get more clients and grow your agency with SEMrush.",tags:["Agency solutions","Lead generation"]},{type:"tool",id:"lead-finder",name:"Lead Finder",url:"https://www.semrush.com/lead-finder/",description:"[Generated] Find leads for your agency and grow your business.",tags:["Agency solutions","Lead generation"]},{type:"tool",id:"bid-finder",name:"Bid Finder",url:"https://www.semrush.com/bid-finder/landing/",status:"beta",description:"[Generated] Find leads for your agency and grow your business.",tags:["Agency solutions","Lead generation"]},{type:"tool",id:"client-portal",name:"Client Portal",url:"https://www.semrush.com/my-insights/dashboard",description:"[Generated] Share your SEMrush data with your clients.",tags:["Agency solutions","Optimization and automation"]},{type:"tool",id:"crm",name:"CRM",url:"https://www.semrush.com/crm/",description:"[Generated] Manage your leads and clients with SEMrush.",tags:["Agency solutions","Optimization and automation"]},{type:"tool",id:"my-reports",name:"My Reports",url:"https://www.semrush.com/my_reports/grid/",description:"[Generated] Create custom reports for your clients.",tags:["Agency solutions","Optimization and automation"]}],Do=[{type:"resource",id:"blog",name:"Blog",description:"Read the industry's latest thoughts on digital marketing, content strategy, SEO, PPC, social media and more.",url:"https://www.semrush.com/blog/"},{type:"resource",id:"help-center",name:"Help Center",description:"Learn how to use Semrush with user manuals, how-to\u2019s, videos and more!",url:"https://www.semrush.com/kb/"},{type:"resource",id:"what-s-new",name:"What's New",description:"Keep track of the newest Semrush features and improvements.",url:"https://www.semrush.com/news/categories/product-news"},{type:"resource",id:"webinars",name:"Webinars",description:"Register and take part in educational webinars conducted by the best digital marketing experts.",url:"https://www.semrush.com/academy/webinars/"},{type:"resource",id:"insights",name:"Insights",description:"See the latest in original research and thought leadership from the Semrush team.",url:"https://www.semrush.com/news/categories/insights"},{type:"resource",id:"hire-a-trusted-agency",name:"Hire a Trusted Agency",description:"Pressed for time? Need rare skills? Get help from a trusted agency. Our experts work with marketing projects of all kinds and budgets.",url:"https://www.semrush.com/agencies/"},{type:"resource",id:"academy",name:"Academy",description:"Get vital SEO skills, learn how to use our toolkits and get official certificates of your proficiency in SEO and Semrush.",url:"https://www.semrush.com/academy/"},{type:"resource",id:"top-websites",name:"Top Websites",description:"Discover the most visited websites. Analyze their traffic and search rankings. Choose country or industry to find out who currently leads the market.",url:"https://www.semrush.com/website/"},{type:"resource",id:"goodcontent-hub",name:"GoodContent Hub",description:"Learn everything you need to know about effective content marketing in one place. Explore free tools, industry research, practical materials for your business, and more.",url:"https://www.semrush.com/goodcontent/"},{type:"resource",id:"local-seo-hub",name:"Local SEO Hub",description:"Are you looking for advanced local search optimization trends, tips and tools? Outperform your competitors in local search and maps with the right SEO strategies by taking a deep dive into our Local SEO Hub.",url:"https://www.semrush.com/local-seo/"}];function Lo(){return[...Go,...Fo,...Do,...zo].map(Mo)}const Bo={favourites:[],pages:[],options:[{id:"toggle-footer",name:"Toggle footer",action:{type:"toggleFooter",payload:null}},{id:"toggle-left-menu",name:"Toggle left menu",action:{type:"toggleLeftMenu",payload:null}},...Lo()]},_o=(e,t)=>{const{type:n,payload:o}=t;switch(n){case"goto":return window.open(o,"_self"),e;case"toggleFooter":return Io.toggle(),e;case"toggleLeftMenu":return Ro.toggle(),e;case"setFavourites":return{...e,favourites:o};case"favToggle":{const{favourites:a}=e;if(a.indexOf(o)===-1){const c={...e,favourites:[...a,o]};return chrome.storage.local.set({favourites:c.favourites}),c}else{const c={...e,favourites:a.filter(i=>i!==o)};return chrome.storage.local.set({favourites:c.favourites}),c}}default:return e}};function Uo(){const[e,t]=r.exports.useReducer(_o,Bo),n=r.exports.useCallback(o=>{typeof o=="function"?o(t):t(o)},[t]);return[e,n]}function No(e){chrome.storage.local.get(["favourites"],t=>{const n=t.favourites||[];e({type:"setFavourites",payload:n})})}const Wo=e=>r.exports.useCallback((t,n)=>{var a;if(!n)return 1;const o=e.options.find(s=>s.id===t);return o?o.name.toLowerCase().includes(n.toLowerCase())?e.favourites.includes(t)?3:2:(a=o.description)!=null&&a.toLowerCase().includes(n.toLowerCase())?1:0:0},[e]);function Ko(){const[e,t]=re.useState(!1),[n,o]=re.useState(""),[a,s]=Uo(),c=Wo(a);r.exports.useCallback(()=>t(!0),[]),re.useEffect(()=>{No(s)},[]),re.useEffect(()=>{const u=h=>{h.key==="k"&&(h.metaKey||h.ctrlKey)&&(h.preventDefault(),t(m=>!m))};return document.addEventListener("keydown",u),()=>document.removeEventListener("keydown",u)},[]);const i=r.exports.useCallback(u=>{u.key==="l"&&(u.metaKey||u.ctrlKey)&&(u.preventDefault(),s({type:"favToggle",payload:n}))},[n]),l=a.options.find(u=>u.id===n);return G(X.Dialog,{value:n,onValueChange:u=>o(u),filter:c,loop:!0,open:e,onOpenChange:t,onKeyDown:i,children:[G("div",{className:"snav-header",children:[$(X.Input,{autoFocus:!0,placeholder:"What are you looking for?"}),$(Yo,{className:"snav-search-icon"})]}),G("div",{className:"snav-content",children:[G(X.List,{className:"snav-list snav-scrollbar",children:[$(X.Empty,{children:"No results found."}),a.favourites.length>0&&a.favourites.map(u=>{const h=a.options.find(m=>m.id===u);return $(ot,{option:h,isFvav:!0,onSelect:()=>s(h.action)},h.id)}),a.options.filter(u=>!a.favourites.includes(u.id)).map(u=>$(ot,{option:u,onSelect:()=>s(u.action)},u.id))]}),$("div",{className:"snav-details snav-scrollbar",children:$(Ho,{option:l,isFav:a.favourites.includes(l==null?void 0:l.id)})})]})]})}const Yo=e=>$("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",fill:"none",...e,children:$("path",{fill:"currentColor",d:"m14.7 13.3-4.5-4.6a5 5 0 1 0-1.5 1.5l4.6 4.5a1 1 0 0 0 1.6-1 1 1 0 0 0-.2-.4ZM3 6a3 3 0 1 1 6 0 3 3 0 0 1-6 0Z"})}),ot=e=>{const{option:t,isFvav:n,onSelect:o}=e;return G(X.Item,{value:t.id,onSelect:o,children:[n&&"\u2605 ",t.name]})},Ho=e=>{var a;const{option:t,isFav:n,onSelect:o}=e;return t?G(ze,{children:[G("h2",{children:[t.name," ",n?"\u2605":""]}),$("p",{children:t.description}),$("div",{className:"snav-tags",children:(a=t.tags)==null?void 0:a.map(s=>$("button",{className:"snav-tag",children:s},s))})]}):null};function qo(){return $(Ko,{})}const De=document.createElement("div");De.id="sem-nav-extension-root";document.body.append(De);Rt(De).render($(qo,{}));
